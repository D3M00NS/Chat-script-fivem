# Python / release/pack_release.py / Python 3.11+ / package locally built Windows artifacts.
from pathlib import Path
import hashlib
import json
import zipfile

PROJECT = Path(__file__).resolve().parents[1]
OUTPUT = PROJECT / "dist" / "packages"
OUTPUT.mkdir(parents=True, exist_ok=True)
SOURCE_PARTS = ("src", "tests", "scripts", "docs", "release")
source_files = [PROJECT / name for name in ("README.md", "global.json", ".gitignore")]
for part in SOURCE_PARTS:
    source_files.extend(path for path in (PROJECT / part).rglob("*")
                        if path.is_file() and not {"bin", "obj", "__pycache__"}.intersection(path.parts))

license_files = {
    "licencas/DotNet-LICENSE.txt": Path("/workspace/zyon-external-menu/tools/nuget/microsoft.netcore.app.runtime.win-x64/8.0.32/LICENSE.TXT"),
    "licencas/WindowsDesktop-LICENSE.txt": Path("/workspace/zyon-external-menu/tools/nuget/microsoft.windowsdesktop.app.runtime.win-x64/8.0.32/LICENSE"),
    "licencas/ThirdPartyNotices.txt": Path("/workspace/zyon-external-menu/tools/dotnet/ThirdPartyNotices.txt"),
}
results = []
for flavor, folder in (("completo", "win-x64"), ("compacto", "compacto")):
    binary_files = sorted(path for path in (PROJECT / "dist" / folder).iterdir() if path.is_file())
    executable = PROJECT / "dist" / folder / "ZyonMenu.exe"
    if not executable.is_file():
        raise FileNotFoundError(executable)
    if flavor == "completo" and [path.name for path in binary_files] != ["ZyonMenu.exe"]:
        raise RuntimeError("O pacote completo precisa conter o executável único publicado.")
    manifest = {
        "product": "Zyon standalone b3258",
        "version": "3.0.0",
        "releaseStatus": "development-preview",
        "target": "Windows 10 x64 / FiveM_b3258_GTAProcess.exe",
        "runtimeIncluded": flavor == "completo",
        "windowsRuntimeTested": False,
        "fiveMRuntimeTested": False,
        "serverResourceRequired": False,
        "localTcpListener": False,
        "unavailableFunctions": ["revive", "serverPlayerIds", "playerNames", "steamIdentity", "silentAim", "noclip", "freezeAmmo", "lineOfSight"],
        "verification": {"portableSuites": 7, "portableAssertions": 101, "mutexProcessChecks": 5, "staticAccessorChecks": 3},
        "binaries": [{"file": path.name, "bytes": path.stat().st_size,
                      "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in binary_files],
    }
    runtime_note = ("O runtime .NET está incluído; abra ZyonMenu.exe.\n" if flavor == "completo" else
                    "Requer .NET Desktop Runtime 8 x64: https://dotnet.microsoft.com/download/dotnet/8.0\n")
    quick_start = (
        "ZYON V3 - PREVIA INDEPENDENTE B3258\n\n"
        "1. Extraia o ZIP inteiro para uma pasta nova.\n"
        "2. Feche o menu antigo e abra ZyonMenu.exe desta pasta.\n"
        "3. Confirme o titulo: Zyon v3 - FiveM b3258 / standalone.\n"
        "4. Abra o FiveM b3258 e entre na cidade; a deteccao do processo e automatica.\n"
        "5. Se a validacao nao concluir, use a engrenagem > Salvar diagnostico.\n\n"
        + runtime_note + "\n"
        "Sem recurso no servidor, grupo admin, chave manual ou porta local.\n"
        "Aim, ESP e GodMode podem ser preparados antes de validar o personagem.\n"
        "Reviver, nomes/IDs, identidade Steam, Silent Aim, Noclip, Freeze Ammo e oclusao permanecem indisponiveis.\n"
        "Compilacao e testes portaveis passaram. A janela Windows e o funcionamento no FiveM ainda nao foram executados aqui.\n"
        "Consulte codigo-fonte/README.md para os campos implementados e seus limites.\n"
    )
    archive = OUTPUT / f"ZyonMenu-v3-standalone-{flavor}.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in binary_files:
            bundle.write(path, "ZyonMenu-v3/" + path.name)
        bundle.writestr("ZyonMenu-v3/LEIA-ME.txt", quick_start.replace("\n", "\r\n"))
        bundle.writestr("ZyonMenu-v3/manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        for path in sorted(source_files):
            bundle.write(path, "ZyonMenu-v3/codigo-fonte/" + path.relative_to(PROJECT).as_posix())
        for destination, path in license_files.items():
            bundle.write(path, "ZyonMenu-v3/" + destination)
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError("ZIP com erro de integridade.")
        forbidden = {"gta-game-five.dll", "gta-net-five.dll", "rage-scripting-five.dll", "scripting-gta.dll",
                     "citizen-resources-gta.dll", "citizen-playernames-five.dll", "Midgard.exe", "Astrix Loader.exe"}
        if any(Path(name).name in forbidden for name in bundle.namelist()):
            raise RuntimeError("Arquivo privado de analise incluido no pacote.")
    results.append({"file": archive.name, "bytes": archive.stat().st_size,
                    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()})
Path(OUTPUT / "packages.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
