#!/usr/bin/env bash
# Bash / scripts/test.sh / .NET 8 SDK / portable geometry, signatures and UI state verification.
set -euo pipefail
zyon_project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
zyon_dotnet_command="${ZYON_DOTNET_COMMAND:-dotnet}"
cd "$zyon_project_root"
"$zyon_dotnet_command" run --project tests/ZyonMenu.Standalone.Tests/ZyonMenu.Standalone.Tests.csproj -c Release
