# PowerShell / scripts/test.ps1 / PowerShell 5.1+ and .NET 8 SDK / portable standalone checks.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    & dotnet run --project tests/ZyonMenu.Standalone.Tests/ZyonMenu.Standalone.Tests.csproj -c Release
    if ($LASTEXITCODE -ne 0) { throw "Os testes falharam com código $LASTEXITCODE." }
} finally {
    Pop-Location
}
