# Zyon standalone b3258 — em desenvolvimento

Projeto independente para `FiveM_b3258_GTAProcess.exe`, separado da versão 2 publicada. Não utiliza recurso instalado no servidor, chave de acesso, API HTTP, grupo admin ou permissão ACE. Esta é uma prévia de desenvolvimento; as funções em **Bloqueios atuais** continuam indisponíveis.

O transporte usa um handle normal do processo Windows x64. Ele não eleva permissões, carrega drivers, injeta código nem escreve páginas executáveis. A falta de acesso ou a divergência das estruturas aparece como diagnóstico; não é tratada como uma conexão funcional.

## Implementação atual

- Detecção do processo b3258 e validação do personagem local por ponteiros, posição, base XYZ da matriz e intervalo de vida. Um processo encontrado permanece identificado por PID mesmo quando o Windows nega acesso; cada etapa de validação possui diagnóstico específico.
- Apenas uma instância por usuário/sessão Windows; uma segunda abertura mostra a janela existente. A versão independente não abre a porta local usada na versão 2.
- Configurações selecionáveis antes da ligação; escolhas iniciais aguardam aplicação. A perda de uma sessão anteriormente aplicada ou a troca do personagem invalida os efeitos anteriores.
- Godmode por bit 8 do DWORD do personagem `+0x188`, documentado pelo CitizenFX. Os demais bits são preservados; restaurar o bit anterior depende de o mesmo personagem continuar válido. Isso não equivale a impedir mudanças de vida ou de estado médico feitas por scripts.
- Aim por direção da câmera, tecla de ativação, FOV e suavização; cabeça/pescoço e ponto aproximado no tronco. Não existe redirecionamento de projéteis.
- ESP de entidades em streaming, caixas, nove ossos e distância. O filtro de jogadores usa o ponteiro de player-info, sem atribuir ID da cidade a uma posição na lista.
- Recoil-shake e spread condicionados a assinaturas únicas nas seções executáveis. Somente os campos de dados são modificados. As restaurações preservam bits originais, conferem identidade/hash e não sobrescrevem um valor posterior diferente do último valor escrito.

## Bloqueios atuais

Reviver, ID da cidade, nomes, identidade Steam, teste de oclusão, noclip, munição e Silent Aim não estão implementados ou validados neste backend. A interface não anuncia essas capacidades. Um PID é identificado como ID do processo, e não como ID da cidade.

Aumentar a vida não implementa `NETWORK_RESURRECT_LOCAL_PLAYER`. Exports de natives pertencem ao processo do FiveM e exigem seu contexto de execução; carregar os DLLs no programa externo não cria uma chamada remota. A análise dos DLLs reais do cliente ainda é necessária para determinar a integração adequada. Os nomes CFX também não provam o nome ou Steam ID autenticado dos outros jogadores.

Foram recebidos e analisados estaticamente `rage-scripting-five.dll`, `scripting-gta.dll` e `gta-game-five.dll`, todos versão `1.0.0.37151`; os resultados estão em [docs/client-37151.md](docs/client-37151.md). Uma busca na instalação efetivamente usada confirmou `gta-net-five.dll`, `citizen-resources-gta.dll` e `citizen-playernames-five.dll`; os arquivos ainda aguardam envio para inspeção. A imagem GTA b3258 ou os dados dos getters resolvidos no processo ainda podem ser necessários para verificar handlers, associação dos jogadores e perfil.

## Uso da prévia

1. Feche o menu antigo da versão 2. Abra `ZyonMenu.exe` deste pacote; o título precisa mostrar **Zyon v3 — FiveM b3258 / standalone**.
2. Abra o FiveM b3258 e entre na cidade. A detecção é automática. Você pode preparar Aim, ESP e GodMode antes de o personagem ser validado; o rodapé informa se a aplicação ainda está pendente.
3. Se a validação não concluir, abra a aba da engrenagem e clique em **Salvar diagnóstico**. O JSON contém o estado da aplicação, módulos selecionados e leituras delimitadas de código de getters; não contém chaves de acesso, nomes de jogadores nem caminhos completos do perfil Windows. Esse arquivo permite investigar o cliente real sem adivinhar offsets.

Este pacote não contém `zyon_admin_menu` nem DLLs de terceiros enviados para análise. Reviver não foi substituído por uma simples alteração de vida. Os controles de funções ainda indisponíveis permanecem identificados na interface.

## Verificação realizada

Compilação Release Windows: zero erros e avisos. Testes portáveis: sete suítes e 101 assertivas de projeção, transformação, assinaturas e política da interface. Cinco verificações de mutex entre processos passaram, incluindo exclusão da segunda instância e recuperação de proprietário encerrado. A ativação da janela e o isolamento por SID/sessão Windows não foram executados neste ambiente Linux.

Os três padrões usados no diagnóstico de accessors também foram comparados diretamente com os bytes do DLL recebido. Essa verificação estática não substitui a captura do módulo efetivamente carregado no jogo.

Nenhum arquivo de terceiros enviado foi executado ou redistribuído. Este ambiente Linux não executou a janela Windows, o transporte Win32 nem uma sessão real do FiveM. Compilação, testes portáveis e inspeção estática não confirmam funcionamento dentro do jogo.

Referências e limites dos campos estão em [docs/fields-b3258.md](docs/fields-b3258.md). Os pacotes v2 publicados permanecem inalterados.

Para recompilar no Windows, instale o SDK .NET `8.0.426` e execute `powershell -ExecutionPolicy Bypass -File scripts/build.ps1` na pasta do código-fonte. Os testes portáveis podem ser executados com `powershell -ExecutionPolicy Bypass -File scripts/test.ps1`. O pacote completo já inclui o runtime necessário para abrir o executável.
