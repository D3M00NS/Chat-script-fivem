// C# / src/ZyonMenu.Windows/Program.cs / .NET 8 WinForms / Windows 10+ x64.
namespace ZyonMenu.Windows;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        using var instance = StandaloneInstance.Acquire();
        if (!instance.IsOwner)
        {
            StandaloneInstance.ActivateExistingWindow();
            return;
        }
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
