-- Lua 5.4 / server_contract.lua / mocked FXServer / HTTP and authorization contract checks.
-- Run from the project root: lua tests/server_contract.lua
local serverPath = (arg[0]:match('^(.*)/tests/[^/]+$') or '.') .. '/fivem/zyon_admin_menu/server.lua'
local function copy(value)
    if type(value) ~= 'table' then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = copy(item) end
    setmetatable(result, getmetatable(value))
    return result
end

local function fixture()
    local f = { clock = 0, token = string.rep('a', 64), license = 'license:' .. string.rep('b', 40),
        players = { '7', '9' }, allowed = { [7] = true, [9] = true }, handlers = {}, threads = {},
        timeouts = {}, effects = {}, decoded = {}, parseCalls = 0, responseCalls = 0 }
    f.identifiers = { [7] = { f.license }, [9] = { 'license:' .. string.rep('c', 40) } }
    function GetCurrentResourceName() return 'zyon_admin_menu' end
    function GetGameTimer() return f.clock end
    function GetConvar(name, fallback)
        if name == 'zyon_menu_token' then return f.token end
        if name == 'zyon_menu_license' then return f.license end
        return fallback
    end
    function GetPlayers() return f.players end
    function GetPlayerIdentifiers(player) return f.identifiers[player] or {} end
    function GetPlayerName(player) return 'Player ' .. player end
    function IsPlayerAceAllowed(player, ace) return ace == 'zyon.modmenu' and f.allowed[player] or false end
    function TriggerClientEvent(event, player, ...) f.effects[#f.effects + 1] = { event = event, player = player, args = copy({ ... }) } end
    function RegisterNetEvent(name, handler) f.handlers[name] = handler end
    function AddEventHandler(name, handler) f.handlers[name] = handler end
    function CreateThread(fn) f.threads[#f.threads + 1] = coroutine.create(fn) end
    function Wait() coroutine.yield() end
    function SetTimeout(delay, fn) f.timeouts[#f.timeouts + 1] = { at = f.clock + delay, fn = fn } end
    function SetHttpHandler(handler) f.http = handler end
    json = {
        encode = function(value) return copy(value) end,
        decode = function(body)
            f.parseCalls = f.parseCalls + 1
            if not f.decoded[body] then error('invalid JSON') end
            return copy(f.decoded[body]), #body + 1, nil
        end
    }
    dofile(serverPath)
    for _, thread in ipairs(f.threads) do assert(coroutine.resume(thread)) end
    function f:advance(milliseconds)
        self.clock = self.clock + milliseconds
        for _, thread in ipairs(self.threads) do assert(coroutine.resume(thread)) end
        for _, timeout in ipairs(self.timeouts) do
            if not timeout.done and self.clock >= timeout.at then timeout.done = true; timeout.fn() end
        end
    end
    function f:request(path, method, payload, options)
        options = options or {}
        local result = {}
        local body = options.body
        if payload then
            body = 'fixture-' .. tostring(#self.effects + self.parseCalls + self.responseCalls + 1)
            self.decoded[body] = copy(payload)
        end
        local request = {
            path = path, method = method, address = '127.0.0.1', headers = {
                Authorization = options.authorization or ('Bearer ' .. self.token),
                ['Content-Type'] = options.contentType or 'application/json'
            },
            setDataHandler = function(callback) result.dataHandler = callback end,
            setCancelHandler = function(callback) result.cancelHandler = callback end
        }
        if options.length then request.headers['Content-Length'] = options.length end
        local response = {
            writeHead = function(status, headers)
                assert(not result.status, 'response headers written twice')
                result.status = status; result.headers = headers
            end,
            send = function(value)
                assert(not result.sent, 'response sent twice')
                result.sent = true; result.payload = value; self.responseCalls = self.responseCalls + 1
            end
        }
        self.http(request, response)
        if result.dataHandler and not options.delayed then result.dataHandler(body or '') end
        result.request = request
        result.body = body
        return result
    end
    function f:event(name, player, ...)
        source = player
        self.handlers[name](...)
        source = nil
    end
    function f:status() return self:request('/api/status', 'GET').payload end
    return f
end

local function settings()
    return {
        aim = { enabled = false, onlyVisible = true, onlyPlayers = true, targetBone = 'Head',
            activationKey = 'RMB', smooth = 1, drawFov = false, fov = 100 },
        silent = { enabled = false, onlyVisible = true, onlyPlayers = true, targetBone = 'Head',
            activationKey = 'RMB', smooth = 1, drawFov = false, fov = 100 },
        weapons = { noRecoil = false, noSpread = false, freezeAmmo = false },
        player = { godMode = true, noclip = false },
        esp = { enabled = false, boxes = true, skeletons = false, names = true, distance = true,
            onlyPlayers = true, onlyVisible = true, maxDistance = 250 }
    }
end

local passed = 0
local function test(name, callback)
    local ok, err = pcall(callback)
    if not ok then error(name .. ': ' .. tostring(err), 0) end
    passed = passed + 1
    print('PASS ' .. name)
end

test('authentication happens before JSON decoding or dispatch', function()
    local f = fixture()
    local result = f:request('/api/settings', 'POST', { settings = settings() }, { authorization = 'Bearer bad' })
    assert(result.status == 401 and f.parseCalls == 0 and #f.effects == 0)
    f.token = 'short'
    assert(f:request('/api/status', 'GET').status == 401)
end)

test('configuration diagnostics remain available with valid secret', function()
    local f = fixture()
    f.license = 'bad-identifier'
    local state = f:status()
    assert(state.ready == false and state.playerOnline == false)
end)

test('license and ACE checks select only configured online player', function()
    local f = fixture()
    local result = f:request('/api/settings', 'POST', { settings = settings() })
    assert(result.status == 200 and #f.effects == 1 and f.effects[1].player == 7)
    f:advance(1000)
    f.allowed[7] = false
    local denied = f:request('/api/settings', 'POST', { settings = settings() })
    assert(denied.status == 409)
    assert(f.effects[#f.effects].player == 7 and f.effects[#f.effects].args[1].player.godMode == false)
end)

test('exact license binding rejects partial or wrong identifiers', function()
    local f = fixture()
    f.identifiers[7] = { f.license .. '0', 'steam:1234' }
    assert(f:request('/api/settings', 'POST', { settings = settings() }).status == 409)
    assert(#f.effects == 0)
end)

test('ACK only accepts current revision from configured permitted player', function()
    local f = fixture()
    local result = f:request('/api/settings', 'POST', { settings = settings() })
    local revision = result.payload.revision
    f:event('zyon_admin_menu:ack', 9, revision)
    assert(f:status().appliedRevision == 0)
    f:event('zyon_admin_menu:ack', 7, revision - 1)
    assert(f:status().appliedRevision == 0)
    f:event('zyon_admin_menu:ack', 7, revision)
    assert(f:status().appliedRevision == revision)
end)

test('failed client ACK restores defaults without claiming application', function()
    local f = fixture()
    local revision = f:request('/api/settings', 'POST', { settings = settings() }).payload.revision
    f:event('zyon_admin_menu:ack', 7, revision, false, 'Native unavailable')
    local state = f:status()
    assert(state.appliedRevision == 0 and state.desiredRevision > revision)
    assert(f.effects[#f.effects].args[1].player.godMode == false)
end)

test('heartbeat expires and resets modifiers after 15 seconds', function()
    local f = fixture()
    f:request('/api/settings', 'POST', { settings = settings() })
    f:advance(14000)
    assert(f.effects[#f.effects].args[1].player.godMode == true)
    f:advance(1000)
    assert(f.effects[#f.effects].args[1].player.godMode == false)
    assert(f:status().message:find('expirada'))
end)

test('status renews session and periodic applies renew client lease', function()
    local f = fixture()
    f:request('/api/settings', 'POST', { settings = settings() })
    f:advance(10000)
    assert(f:status().playerOnline)
    f:advance(10000)
    assert(f.effects[#f.effects].args[1].player.godMode == true)
    f:advance(5000)
    assert(f.effects[#f.effects].args[1].player.godMode == false)
end)

test('malformed, oversized and misleading MIME bodies are rejected', function()
    local f = fixture()
    assert(f:request('/api/settings', 'POST', nil, { body = '{broken' }).status == 400)
    assert(f:request('/api/settings', 'POST', nil, { body = string.rep('x', 32769) }).status == 413)
    assert(f:request('/api/settings', 'POST', { settings = settings() }, { contentType = 'application/jsonbad' }).status == 415)
    assert(f:request('/api/settings', 'POST', nil, { length = '32769' }).status == 413)
    assert(#f.effects == 0)
end)

test('silent aim rejection is atomic and bounds/unknown fields are enforced', function()
    local f = fixture()
    local value = settings(); value.silent.enabled = true
    assert(f:request('/api/settings', 'POST', { settings = value }).status == 422)
    value = settings(); value.aim.fov = 501
    assert(f:request('/api/settings', 'POST', { settings = value }).status == 422)
    value = settings(); value.player.arbitraryTarget = 9
    assert(f:request('/api/settings', 'POST', { settings = value }).status == 422)
    assert(#f.effects == 0)
end)

test('decoder errors, trailing data and JSON arrays are rejected', function()
    local f = fixture()
    json.decode = function() return {}, 3, 'decoder failure' end
    assert(f:request('/api/settings', 'POST', nil, { body = '{}' }).status == 400)
    json.decode = function() return {}, 3, nil end
    assert(f:request('/api/settings', 'POST', nil, { body = '{} trailing' }).status == 400)
    json.decode = function(body) return setmetatable({}, { __jsontype = 'array' }), #body + 1, nil end
    assert(f:request('/api/revive', 'POST', nil, { body = '[]' }).status == 422)
    assert(#f.effects == 0)
end)

test('endpoint rate limits and allowed methods are bounded', function()
    local f = fixture()
    assert(f:request('/api/status', 'POST', {}).status == 405)
    assert(f:request('/api/console', 'POST', {}).status == 404)
    for _ = 1, 8 do assert(f:request('/api/status', 'GET').status == 200) end
    assert(f:request('/api/status', 'GET').status == 429)
    f:advance(1000)
    assert(f:request('/api/status', 'GET').status == 200)
end)

test('revive tickets reject forgery and permit a single matching ACK', function()
    local f = fixture()
    f:event('zyon_admin_menu:reviveAck', 7, 1, true, 'forged')
    assert(#f:request('/api/events', 'GET').payload.events == 0)
    local result = f:request('/api/revive', 'POST', {})
    assert(result.status == 200)
    local ticket = result.payload.ticket
    f:event('zyon_admin_menu:reviveAck', 9, ticket, true, 'forged')
    f:event('zyon_admin_menu:reviveAck', 7, ticket + 1, true, 'forged')
    f:event('zyon_admin_menu:reviveAck', 7, ticket, true, 'revived')
    local cursor = f:request('/api/events', 'GET').payload.cursor
    f:event('zyon_admin_menu:reviveAck', 7, ticket, true, 'duplicate')
    assert(f:request('/api/events', 'GET').payload.cursor == cursor)
    assert(f.effects[1].event == 'zyon_admin_menu:apply' and f.effects[1].args[2] > 0)
end)

test('credential rotation during pending body prevents execution', function()
    local f = fixture()
    local result = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
    f.token = string.rep('d', 64)
    result.dataHandler('ignored')
    assert(result.status == 401 and f.parseCalls == 0 and #f.effects == 0)
end)

test('body timeout and cancellation cannot produce duplicate responses', function()
    local f = fixture()
    local result = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
    f:advance(5000)
    assert(result.status == 408)
    result.dataHandler('ignored')
    assert(#f.effects == 0)
    local canceled = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
    canceled.cancelHandler()
    f:advance(5000)
    canceled.dataHandler('ignored')
    assert(not canceled.status and #f.effects == 0)
end)

test('disconnect and resource shutdown restore active modifiers', function()
    local f = fixture()
    f:request('/api/settings', 'POST', { settings = settings() })
    assert(f:request('/api/disconnect', 'POST', {}).status == 200)
    assert(f.effects[#f.effects].args[1].player.godMode == false)
    f:advance(1000)
    f:request('/api/settings', 'POST', { settings = settings() })
    f:event('onResourceStop', 0, 'zyon_admin_menu')
    assert(f.effects[#f.effects].args[1].player.godMode == false)
end)

test('newer mutation fences settings bodies received in reverse order', function()
    local f = fixture()
    local older = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
    local newerSettings = settings(); newerSettings.player.godMode = false
    local newer = f:request('/api/settings', 'POST', { settings = newerSettings })
    assert(newer.status == 200)
    older.dataHandler(older.body)
    assert(older.status == 409 and #f.effects == 1)
    assert(f.effects[1].args[1].player.godMode == false)
end)

test('disconnect fences older settings and revive bodies', function()
    for _, path in ipairs({ '/api/settings', '/api/revive' }) do
        local f = fixture()
        local payload = path == '/api/settings' and { settings = settings() } or {}
        local pending = f:request(path, 'POST', payload, { delayed = true })
        assert(f:request('/api/disconnect', 'POST', {}).status == 200)
        pending.dataHandler(pending.body)
        assert(pending.status == 409 and #f.effects == 0)
        assert(f:status().sessionActive == false)
    end
end)

test('expiry and permission loss fence pending authenticated mutation', function()
    for _, change in ipairs({ 'expiry', 'permission' }) do
        local f = fixture()
        f:request('/api/settings', 'POST', { settings = settings() })
        local pending = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
        if change == 'expiry' then
            -- Place arrival after lease expiry without firing the HTTP receive timeout first.
            f.clock = 15000
        else f.allowed[7] = false end
        pending.dataHandler(pending.body)
        assert(pending.status == 409)
        assert(f.effects[#f.effects].args[1].player.godMode == false)
        assert(f:status().sessionActive == false)
    end
end)

test('a newer malformed mutation still invalidates an older pending body', function()
    local f = fixture()
    local older = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
    assert(f:request('/api/settings', 'POST', nil, { body = '{broken' }).status == 400)
    older.dataHandler(older.body)
    assert(older.status == 409 and #f.effects == 0)
end)

test('license change and reconnect cannot retarget an older HTTP body', function()
    for _, change in ipairs({ 'license', 'reconnect' }) do
        local f = fixture()
        local pending = f:request('/api/settings', 'POST', { settings = settings() }, { delayed = true })
        if change == 'license' then f.license = f.identifiers[9][1]
        else f.players = { '9' }; f.identifiers[9] = { f.license } end
        pending.dataHandler(pending.body)
        assert(pending.status == 409 and #f.effects == 0)
    end
end)

print(string.format('%d server contract checks passed', passed))
