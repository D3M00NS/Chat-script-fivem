// C# / src/ZyonMenu.Windows/MainForm.cs / .NET 8 WinForms / Windows 10+ x64.
using System.Text.Json;
using ZyonMenu.Core;

namespace ZyonMenu.Windows;

internal sealed class MainForm : Form
{
    private readonly MenuSettings _settings = new();
    private readonly Dictionary<string, Control> _pages = new();
    private readonly Dictionary<string, Button> _navigation = new();
    private readonly Dictionary<string, List<Control>> _capabilityControls = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<(ToggleSwitch Control, Func<bool> Getter)> _toggleBindings = new();
    private readonly ToolTip _tooltips = new();
    private readonly System.Windows.Forms.Timer _debounce = new() { Interval = 450 };
    private readonly System.Windows.Forms.Timer _poll = new() { Interval = 1600 };
    private readonly Panel _content = new() { Dock = DockStyle.Fill, BackColor = Theme.Background, Padding = new Padding(24, 16, 12, 12) };
    private readonly Label _connectionLabel = Theme.Label("DESCONECTADO", true);
    private readonly Label _hotkeyLabel = Theme.Label("Insert · ocultar / mostrar", true);
    private readonly Label _revisionLabel = Theme.Label("Conecte ao recurso do seu servidor.", true);
    private readonly Label _serverLabel = Theme.Label("", true);
    private readonly Label _connectionDetails = Theme.Label("Nenhuma conexão estabelecida.", true);
    private readonly TextBox _endpoint = Theme.TextBox();
    private readonly TextBox _token = Theme.TextBox(true);
    private readonly TextBox _eventLog = new();
    private readonly Button _connect = Theme.Button("Conectar", true);
    private readonly Button _disconnect = Theme.Button("Desconectar");
    private readonly Button _revive = Theme.Button("Reviver personagem", true);
    private MenuApiClient? _client;
    private CancellationTokenSource? _session;
    private ServerStatus? _lastStatus;
    private bool _healthy;
    private bool _connecting;
    private bool _polling;
    private bool _sending;
    private bool _disconnecting;
    private bool _reviving;
    private bool _closing;
    private bool _dirty = true;
    private bool _synchronizing;
    private bool _hotkeyRegistered;
    private long _changeVersion;
    private long _connectionGeneration;
    private long _eventsCursor;

    public MainForm()
    {
        Text = "Zyon — FiveM / menu externo";
        Size = new Size(1100, 790);
        MinimumSize = new Size(950, 660);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Theme.Background;
        ForeColor = Theme.Text;
        Font = new Font("Segoe UI", 10f);
        AutoScaleMode = AutoScaleMode.Dpi;
        DoubleBuffered = true;

        BuildShell();
        BuildAimPage();
        BuildPlayerPage();
        BuildEspPage();
        BuildWeaponsPage();
        BuildConnectionPage();
        ShowPage("Aim");

        _debounce.Tick += async (_, _) => { _debounce.Stop(); await SendSettingsAsync(); };
        _poll.Tick += async (_, _) => await PollAsync();
        _connect.Click += async (_, _) => await ConnectAsync();
        _disconnect.Click += async (_, _) => await DisconnectAsync();
        _revive.Click += async (_, _) => await ReviveAsync();
        FormClosing += OnFormClosing;
        UpdateAvailability();
    }

    private void BuildShell()
    {
        var sidebar = new Panel { Dock = DockStyle.Left, Width = 86, BackColor = Theme.Sidebar, Padding = new Padding(10, 18, 10, 12) };
        var mark = new Label
        {
            Text = "Z",
            Font = new Font("Segoe UI", 27, FontStyle.Bold),
            ForeColor = Theme.Accent,
            BackColor = Theme.Sidebar,
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Top,
            Height = 64
        };
        var links = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            Padding = new Padding(0, 22, 0, 0),
            BackColor = Theme.Sidebar
        };
        foreach (var (name, icon, caption) in new[]
                 {
                     ("Aim", "◎", "Aim"),
                     ("Player", "♟", "Personagem"),
                     ("ESP", "◉", "ESP"),
                     ("Weapons", "⌁", "Armas"),
                     ("Connection", "⚙", "Conexão")
                 })
        {
            var button = Theme.Button(icon);
            button.Width = 64;
            button.Height = 58;
            button.Margin = new Padding(0, 0, 0, 12);
            button.Font = new Font("Segoe UI Symbol", 24f);
            button.BackColor = Theme.Sidebar;
            button.FlatAppearance.BorderSize = 0;
            button.AccessibleName = caption;
            button.Click += (_, _) => ShowPage(name);
            _tooltips.SetToolTip(button, caption);
            _navigation.Add(name, button);
            links.Controls.Add(button);
        }
        sidebar.Controls.Add(links);
        sidebar.Controls.Add(mark);

        var main = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };
        var header = new Panel { Dock = DockStyle.Top, Height = 84, Padding = new Padding(26, 15, 26, 8), BackColor = Theme.Background };
        var title = Theme.Label("ZYON  /  MENU EXTERNO");
        title.Font = new Font("Segoe UI", 13f, FontStyle.Bold);
        title.Location = new Point(26, 16);
        var subtitle = Theme.Label("FiveM · controle do recurso instalado no seu servidor", true);
        subtitle.Location = new Point(27, 45);
        _connectionLabel.AutoSize = false;
        _connectionLabel.Size = new Size(290, 24);
        _connectionLabel.TextAlign = ContentAlignment.MiddleRight;
        _connectionLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _connectionLabel.Location = new Point(header.Width - 316, 17);
        _hotkeyLabel.AutoSize = false;
        _hotkeyLabel.Size = new Size(290, 24);
        _hotkeyLabel.TextAlign = ContentAlignment.MiddleRight;
        _hotkeyLabel.Font = new Font("Segoe UI", 8.5f);
        _hotkeyLabel.Location = new Point(header.Width - 316, 44);
        _hotkeyLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        header.Resize += (_, _) =>
        {
            _connectionLabel.Location = new Point(header.Width - 316, 17);
            _hotkeyLabel.Location = new Point(header.Width - 316, 44);
        };
        _tooltips.SetToolTip(_hotkeyLabel, "Insert oculta ou mostra o menu. A sessão permanece conectada enquanto a janela está oculta.");
        header.Controls.AddRange(new Control[] { title, subtitle, _connectionLabel, _hotkeyLabel });

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 54, Padding = new Padding(26, 5, 24, 5), BackColor = Theme.Sidebar };
        _revisionLabel.Location = new Point(26, 8);
        _serverLabel.Location = new Point(26, 29);
        _serverLabel.Font = new Font("Segoe UI", 8f);
        footer.Controls.AddRange(new Control[] { _revisionLabel, _serverLabel });
        main.Controls.Add(_content);
        main.Controls.Add(footer);
        main.Controls.Add(header);
        Controls.Add(main);
        Controls.Add(sidebar);
    }

    private FlowLayoutPanel NewPage(string name)
    {
        var page = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            AutoScroll = true,
            BackColor = Theme.Background,
            Visible = false,
            Margin = Padding.Empty
        };
        _pages[name] = page;
        _content.Controls.Add(page);
        return page;
    }

    private static RoundedCard Card(string title, int width = 408, int height = 440)
    {
        var card = new RoundedCard { Width = width, Height = height };
        var heading = Theme.Label(title);
        heading.ForeColor = Theme.Accent;
        heading.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
        heading.Location = new Point(20, 18);
        card.Controls.Add(heading);
        return card;
    }

    private void BuildAimPage()
    {
        var page = NewPage("Aim");
        page.Controls.Add(AimCard("Aimbot Aim", _settings.Aim, "aim"));
        var silentCard = AimCard("Silent Aim", _settings.Silent, "silent");
        silentCard.Height = 485;
        AddNote(silentCard, "Redirecionamento de projéteis não implementado nesta integração.", 424, 360);
        page.Controls.Add(silentCard);
        page.Controls.Add(WeaponsCard(408));
        var note = Card("Aplicação", 408, 186);
        AddNote(note, "As opções são enviadas ao recurso autorizado do servidor. A barra inferior informa quando o cliente FiveM confirmou a revisão. Sem o recurso ativo, nenhuma função é aplicada.", 61, 360);
        page.Controls.Add(note);
    }

    private RoundedCard AimCard(string title, AimSettings settings, string capability)
    {
        var card = Card(title);
        var y = 60;
        AddToggle(card, "Ativar " + title, () => settings.Enabled, v => settings.Enabled = v, capability, y); y += 40;
        AddToggle(card, "Somente visível", () => settings.OnlyVisible, v => settings.OnlyVisible = v, capability, y); y += 40;
        AddChoice(card, "Alvo", new[] { "Head", "Neck", "Chest" }, new[] { "Cabeça", "Pescoço", "Peito" }, settings.TargetBone, v => settings.TargetBone = v, capability, y); y += 40;
        AddToggle(card, "Apenas jogadores", () => settings.OnlyPlayers, v => settings.OnlyPlayers = v, capability, y); y += 40;
        AddChoice(card, "Tecla de ativação", new[] { "RMB", "LMB", "Alt", "Shift", "Ctrl" }, new[] { "Mouse [Mirar]", "Mouse [Atirar]", "Alt", "Shift", "Ctrl" }, settings.ActivationKey, v => settings.ActivationKey = v, capability, y); y += 40;
        AddSlider(card, "Suavização", 1, 20, settings.Smooth, v => settings.Smooth = v, capability, y); y += 40;
        AddToggle(card, "Desenhar FOV", () => settings.DrawFov, v => settings.DrawFov = v, capability, y); y += 40;
        AddSlider(card, "FOV", 10, 500, settings.Fov, v => settings.Fov = v, capability, y);
        return card;
    }

    private void BuildPlayerPage()
    {
        var page = NewPage("Player");
        var card = Card("Personagem", 408, 250);
        AddToggle(card, "GodMode", () => _settings.Player.GodMode, v => _settings.Player.GodMode = v, "player.godMode", 64);
        AddToggle(card, "Noclip", () => _settings.Player.Noclip, v => _settings.Player.Noclip = v, "player.noclip", 106);
        _revive.Text = "Reviver (nativo)";
        _tooltips.SetToolTip(_revive, "Revive pelo recurso nativo. Scripts de morte da cidade podem exigir integração adicional.");
        _revive.Location = new Point(20, 166);
        _revive.Width = 220;
        card.Controls.Add(_revive);
        RegisterCapability("player.revive", _revive);
        page.Controls.Add(card);
        var note = Card("Estado do personagem", 408, 250);
        AddNote(note, "Entre no servidor com o jogador vinculado à sua chave. Reviver é uma ação imediata; GodMode e Noclip permanecem ativos até serem desativados ou a sessão expirar. O menu precisa permanecer conectado.", 62, 360);
        page.Controls.Add(note);
    }

    private void BuildEspPage()
    {
        var page = NewPage("ESP");
        var card = Card("ESP", 408, 435);
        var y = 62;
        AddToggle(card, "Ativar ESP", () => _settings.Esp.Enabled, v => _settings.Esp.Enabled = v, "esp", y); y += 40;
        AddToggle(card, "Caixas", () => _settings.Esp.Boxes, v => _settings.Esp.Boxes = v, "esp", y); y += 40;
        AddToggle(card, "Esqueleto", () => _settings.Esp.Skeletons, v => _settings.Esp.Skeletons = v, "esp", y); y += 40;
        AddToggle(card, "Nomes", () => _settings.Esp.Names, v => _settings.Esp.Names = v, "esp", y); y += 40;
        AddToggle(card, "Distância", () => _settings.Esp.Distance, v => _settings.Esp.Distance = v, "esp", y); y += 40;
        AddToggle(card, "Apenas jogadores", () => _settings.Esp.OnlyPlayers, v => _settings.Esp.OnlyPlayers = v, "esp", y); y += 40;
        AddToggle(card, "Somente visível", () => _settings.Esp.OnlyVisible, v => _settings.Esp.OnlyVisible = v, "esp", y); y += 40;
        AddSlider(card, "Alcance (m)", 25, 1000, _settings.Esp.MaxDistance, v => _settings.Esp.MaxDistance = v, "esp", y);
        page.Controls.Add(card);
        var note = Card("Renderização", 408, 222);
        AddNote(note, "O ESP aparece no cliente FiveM pelo recurso do servidor. Este executável controla as configurações; a janela não lê memória de processos. Jogadores fora do alcance disponível ao cliente não aparecem.", 62, 360);
        page.Controls.Add(note);
    }

    private void BuildWeaponsPage()
    {
        var page = NewPage("Weapons");
        page.Controls.Add(WeaponsCard(408));
        var note = Card("Armas", 408, 220);
        AddNote(note, "A disponibilidade vem do recurso conectado. Opções que o servidor não suporta ficam bloqueadas. Os efeitos são confirmados na revisão aplicada exibida abaixo.", 62, 360);
        page.Controls.Add(note);
    }

    private RoundedCard WeaponsCard(int width)
    {
        var card = Card("Weapons Settings", width, 212);
        AddToggle(card, "No Recoil", () => _settings.Weapons.NoRecoil, v => _settings.Weapons.NoRecoil = v, "weapons.noRecoil", 64);
        AddToggle(card, "No Spread", () => _settings.Weapons.NoSpread, v => _settings.Weapons.NoSpread = v, "weapons.noSpread", 106);
        AddToggle(card, "Freeze Ammo", () => _settings.Weapons.FreezeAmmo, v => _settings.Weapons.FreezeAmmo = v, "weapons.freezeAmmo", 148);
        return card;
    }

    private void BuildConnectionPage()
    {
        var page = NewPage("Connection");
        var card = Card("Conexão com o servidor", 834, 385);
        var endpointLabel = Theme.Label("URL do recurso");
        endpointLabel.Location = new Point(20, 60);
        _endpoint.Dock = DockStyle.None;
        _endpoint.Location = new Point(20, 87);
        _endpoint.Size = new Size(790, 30);
        _endpoint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _endpoint.Text = LoadEndpoint();
        _endpoint.AccessibleName = "URL do recurso do servidor";
        var tokenLabel = Theme.Label("Chave de acesso");
        tokenLabel.Location = new Point(20, 132);
        _token.Dock = DockStyle.None;
        _token.Location = new Point(20, 160);
        _token.Size = new Size(790, 30);
        _token.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _token.AccessibleName = "Chave de acesso";
        var note = Theme.Label("A chave fica somente nesta sessão. HTTPS é obrigatório fora de localhost.", true);
        note.Location = new Point(20, 205);
        _connect.Location = new Point(20, 243);
        _disconnect.Location = new Point(180, 243);
        _connectionDetails.AutoSize = false;
        _connectionDetails.Location = new Point(20, 300);
        _connectionDetails.Size = new Size(790, 62);
        _connectionDetails.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        card.Controls.AddRange(new Control[] { endpointLabel, _endpoint, tokenLabel, _token, note, _connect, _disconnect, _connectionDetails });
        page.Controls.Add(card);

        var events = Card("Eventos e diagnóstico", 834, 263);
        _eventLog.Multiline = true;
        _eventLog.ReadOnly = true;
        _eventLog.BorderStyle = BorderStyle.None;
        _eventLog.BackColor = Theme.Card;
        _eventLog.ForeColor = Theme.Muted;
        _eventLog.Font = new Font("Consolas", 9f);
        _eventLog.ScrollBars = ScrollBars.Vertical;
        _eventLog.Location = new Point(20, 57);
        _eventLog.Size = new Size(790, 185);
        _eventLog.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        events.Controls.Add(_eventLog);
        page.Controls.Add(events);
        page.SizeChanged += (_, _) =>
        {
            var width = Math.Max(430, Math.Min(834, page.ClientSize.Width - 24));
            card.Width = width;
            events.Width = width;
        };
    }

    private static void AddNote(Control card, string text, int top, int width)
    {
        var label = Theme.Label(text, true);
        label.AutoSize = false;
        label.Location = new Point(20, top);
        label.Size = new Size(width, card.Height - top - 15);
        card.Controls.Add(label);
    }

    private void AddToggle(Control card, string caption, Func<bool> getter, Action<bool> setter, string capability, int y)
    {
        var label = Theme.Label(caption);
        label.Location = new Point(20, y + 3);
        var toggle = new ToggleSwitch { Checked = getter(), Location = new Point(card.Width - 66, y), AccessibleName = caption };
        toggle.CheckedChanged += (_, _) =>
        {
            if (_synchronizing) return;
            setter(toggle.Checked);
            SettingsChanged();
        };
        _toggleBindings.Add((toggle, getter));
        if (capability == "silent")
            _tooltips.SetToolTip(toggle, "Redirecionamento de projéteis não implementado nesta integração.");
        if (capability == "weapons.noRecoil")
            _tooltips.SetToolTip(toggle, "Recuo nativo da arma; scripts da cidade podem controlar a câmera separadamente.");
        if (capability == "player.godMode")
            _tooltips.SetToolTip(toggle, "Imunidade a dano nativo; scripts que alteram saúde ou estado de morte do framework podem prevalecer.");
        card.Controls.AddRange(new Control[] { label, toggle });
        RegisterCapability(capability, toggle);
    }

    private void AddChoice(Control card, string caption, string[] values, string[] labels, string value, Action<string> setter, string capability, int y)
    {
        var label = Theme.Label(caption);
        label.Location = new Point(20, y + 4);
        var combo = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Field,
            ForeColor = Theme.Text,
            Font = new Font("Segoe UI", 9f),
            Size = new Size(168, 26),
            Location = new Point(card.Width - 192, y),
            AccessibleName = caption
        };
        combo.Items.AddRange(labels.Cast<object>().ToArray());
        combo.SelectedIndex = Math.Max(0, Array.IndexOf(values, value));
        combo.SelectedIndexChanged += (_, _) => { setter(values[combo.SelectedIndex]); SettingsChanged(); };
        card.Controls.AddRange(new Control[] { label, combo });
        RegisterCapability(capability, combo);
    }

    private void AddSlider(Control card, string caption, int min, int max, int value, Action<int> setter, string capability, int y)
    {
        var label = Theme.Label(caption);
        label.Location = new Point(20, y + 3);
        var slider = new AccentSlider { Minimum = min, Maximum = max, Value = value, Location = new Point(card.Width - 211, y), Width = 133, AccessibleName = caption };
        var number = Theme.Label(value.ToString());
        number.AutoSize = false;
        number.Size = new Size(50, 24);
        number.TextAlign = ContentAlignment.MiddleCenter;
        number.BackColor = Theme.Field;
        number.Location = new Point(card.Width - 72, y + 1);
        slider.ValueChanged += (_, _) => { number.Text = slider.Value.ToString(); setter(slider.Value); SettingsChanged(); };
        card.Controls.AddRange(new Control[] { label, slider, number });
        RegisterCapability(capability, slider);
    }

    private void RegisterCapability(string capability, Control control)
    {
        if (!_capabilityControls.TryGetValue(capability, out var controls))
            _capabilityControls[capability] = controls = new List<Control>();
        controls.Add(control);
    }

    private void ShowPage(string name)
    {
        foreach (var (key, page) in _pages) page.Visible = key == name;
        foreach (var (key, button) in _navigation)
        {
            button.BackColor = key == name ? Theme.Field : Theme.Sidebar;
            button.ForeColor = key == name ? Theme.Accent : Theme.Muted;
        }
    }

    private void SettingsChanged()
    {
        SynchronizeToggles();
        _dirty = true;
        _changeVersion++;
        if (_healthy && !_disconnecting && _lastStatus is { Ready: true, PlayerOnline: true })
        {
            _revisionLabel.Text = "Alterações aguardando envio…";
            _debounce.Stop();
            _debounce.Start();
        }
    }

    private void SynchronizeToggles()
    {
        _synchronizing = true;
        try
        {
            foreach (var binding in _toggleBindings) binding.Control.Checked = binding.Getter();
        }
        finally { _synchronizing = false; }
    }

    private async Task ConnectAsync()
    {
        if (_connecting || _client is not null) return;
        if (string.IsNullOrWhiteSpace(_token.Text))
        {
            _connectionDetails.Text = "Informe a chave configurada no recurso do servidor.";
            ShowPage("Connection");
            _token.Focus();
            return;
        }

        MenuApiClient candidate;
        try { candidate = new MenuApiClient(MenuApiClient.ValidateBaseUri(_endpoint.Text.Trim()), _token.Text.Trim()); }
        catch (ArgumentException error)
        {
            _connectionDetails.Text = error.Message;
            return;
        }

        _connecting = true;
        _client = candidate;
        _session = new CancellationTokenSource();
        var generation = ++_connectionGeneration;
        var cancellation = _session.Token;
        _connectionLabel.Text = "CONECTANDO…";
        _connectionLabel.ForeColor = Theme.Warning;
        _connectionDetails.Text = "Validando conexão, chave de acesso e estado do recurso…";
        UpdateAvailability();

        try
        {
            var status = await candidate.GetStatusAsync(cancellation);
            if (generation != _connectionGeneration || _closing) return;
            _connecting = false;
            _healthy = true;
            _lastStatus = status;
            _eventsCursor = 0;
            _dirty = true;
            _poll.Start();
            ApplyStatus(status);
            AppendLog("Conexão autenticada com o recurso.");
            SaveEndpoint(_endpoint.Text.Trim());
            await SendSettingsAsync();
        }
        catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
        catch (Exception error)
        {
            if (generation != _connectionGeneration || _closing) return;
            AppendLog("Conexão falhou: " + error.Message);
            ClearSession();
            _connectionDetails.Text = error.Message;
        }
        finally
        {
            if (generation == _connectionGeneration && !_closing)
            {
                _connecting = false;
                UpdateAvailability();
            }
        }
    }

    private async Task SendSettingsAsync()
    {
        if (_sending || _disconnecting || !_dirty || !_healthy || _lastStatus is not { Ready: true, PlayerOnline: true } || _client is null || _session is null) return;
        var client = _client;
        var cancellation = _session.Token;
        var generation = _connectionGeneration;
        var changeVersion = _changeVersion;
        var snapshot = JsonSerializer.Deserialize<MenuSettings>(JsonSerializer.Serialize(_settings))!;
        _sending = true;
        _revisionLabel.Text = "Enviando configurações…";
        try
        {
            await client.PushSettingsAsync(snapshot, cancellation);
            if (generation != _connectionGeneration || _closing) return;
            _dirty = changeVersion != _changeVersion;
            _revisionLabel.Text = _dirty ? "Novas alterações aguardando envio…" : "Configurações enviadas; aguardando confirmação do FiveM…";
            if (_dirty) _debounce.Start();
        }
        catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
        catch (Exception error)
        {
            if (generation != _connectionGeneration || _closing) return;
            _healthy = false;
            ResetActiveEffects();
            _connectionLabel.Text = "ERRO DE CONEXÃO";
            _connectionLabel.ForeColor = Theme.Warning;
            _connectionDetails.Text = error.Message;
            _revisionLabel.Text = "Envio não confirmado. Efeitos anteriores podem persistir até 15 s; verificando conexão…";
            AppendLog("Falha ao enviar configurações: " + error.Message);
            UpdateAvailability();
        }
        finally { if (generation == _connectionGeneration) _sending = false; }
    }

    private async Task PollAsync()
    {
        if (_polling || _connecting || _client is null || _session is null) return;
        var client = _client;
        var cancellation = _session.Token;
        var generation = _connectionGeneration;
        _polling = true;
        try
        {
            var status = await client.GetStatusAsync(cancellation);
            if (generation != _connectionGeneration || _closing) return;
            var recovered = !_healthy;
            _healthy = true;
            _lastStatus = status;
            ApplyStatus(status);
            if (recovered) AppendLog("Conexão com o recurso recuperada.");
            if (_dirty && !_debounce.Enabled && !_sending) _debounce.Start();
            var events = await client.GetEventsAsync(_eventsCursor, cancellation);
            if (generation != _connectionGeneration || _closing) return;
            foreach (var item in events.Events) AppendLog(item.Type + ": " + item.Message);
            _eventsCursor = events.Cursor;
        }
        catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
        catch (Exception error)
        {
            if (generation != _connectionGeneration || _closing) return;
            if (_healthy) AppendLog("Conexão indisponível: " + error.Message);
            _healthy = false;
            ResetActiveEffects();
            _connectionLabel.Text = "SEM CONFIRMAÇÃO";
            _connectionLabel.ForeColor = Theme.Warning;
            _connectionDetails.Text = error.Message;
            _revisionLabel.Text = "Estado indisponível. Efeitos anteriores podem persistir até 15 s; verificando conexão…";
            UpdateAvailability();
        }
        finally { if (generation == _connectionGeneration) _polling = false; }
    }

    private void ApplyStatus(ServerStatus status)
    {
        if (!status.Ready || !status.PlayerOnline || !status.SessionActive) ResetActiveEffects();
        _connectionLabel.Text = status.Ready && status.PlayerOnline && status.SessionActive ? "CONECTADO"
            : status.Ready && status.PlayerOnline ? "INICIANDO SESSÃO"
            : status.Ready ? "AGUARDANDO JOGADOR" : "RECURSO INDISPONÍVEL";
        _connectionLabel.ForeColor = status.Ready && status.PlayerOnline && status.SessionActive ? Theme.Success : Theme.Warning;
        _connectionDetails.Text = status.Message;
        _serverLabel.Text = status.PlayerOnline
            ? $"Jogador: {status.PlayerName} (ID {status.PlayerId}) · recurso {status.Version}"
            : $"Recurso {status.Version} · jogador vinculado ainda não está online";
        if (!status.Ready || !status.PlayerOnline)
            _revisionLabel.Text = "Sem sessão disponível. Opções locais desativadas; efeitos anteriores podem persistir até 15 s.";
        else if (!status.SessionActive)
            _revisionLabel.Text = "Sem sessão ativa. Enviando opções desativadas para iniciar uma nova sessão…";
        else if (!_dirty && !_sending)
        {
            _revisionLabel.Text = status.AppliedRevision == status.DesiredRevision
                ? $"Revisão {status.AppliedRevision}: o script do cliente reportou a aplicação."
                : $"Revisão enviada {status.DesiredRevision}; aplicada {status.AppliedRevision}. Aguardando cliente FiveM…";
        }
        else if (_dirty && !_sending) _revisionLabel.Text = "Opções locais aguardando envio ao cliente FiveM…";
        UpdateAvailability();
    }

    private void UpdateAvailability()
    {
        var connected = _client is not null;
        _connect.Enabled = !connected && !_connecting;
        _disconnect.Enabled = connected && !_closing && !_disconnecting;
        _endpoint.Enabled = !connected;
        _token.Enabled = !connected;
        var available = !_disconnecting && _healthy && _lastStatus is { Ready: true, PlayerOnline: true, SessionActive: true };
        var capabilities = new HashSet<string>(_lastStatus?.Capabilities ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
        foreach (var (capability, controls) in _capabilityControls)
            foreach (var control in controls)
                control.Enabled = capability != "silent" && available && capabilities.Contains(capability);
        if (_reviving) _revive.Enabled = false;
    }

    private async Task ReviveAsync()
    {
        if (_reviving || !_revive.Enabled || _client is null || _session is null) return;
        var client = _client;
        var cancellation = _session.Token;
        var generation = _connectionGeneration;
        _reviving = true;
        _revive.Enabled = false;
        try
        {
            await client.ReviveAsync(cancellation);
            if (generation != _connectionGeneration || _closing) return;
            AppendLog("Pedido de reviver enviado; aguardando evento do cliente.");
        }
        catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
        catch (Exception error)
        {
            if (generation == _connectionGeneration && !_closing)
            {
                AppendLog("Reviver falhou: " + error.Message);
                _healthy = false;
                ResetActiveEffects();
                _connectionLabel.Text = "SEM CONFIRMAÇÃO";
                _connectionLabel.ForeColor = Theme.Warning;
                _connectionDetails.Text = error.Message;
                _revisionLabel.Text = "Estado indisponível. Efeitos anteriores podem persistir até 15 s; verificando conexão…";
                UpdateAvailability();
            }
        }
        finally
        {
            if (generation == _connectionGeneration)
            {
                _reviving = false;
                if (!_closing) UpdateAvailability();
            }
        }
    }

    private async Task DisconnectAsync()
    {
        if (_client is null || _disconnecting) return;
        _disconnecting = true;
        var client = _client;
        var wasHealthy = _healthy;
        _poll.Stop();
        _debounce.Stop();
        _disconnect.Enabled = false;
        _connectionLabel.Text = "DESCONECTANDO…";
        UpdateAvailability();
        _session?.Cancel();
        ++_connectionGeneration;
        try
        {
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(4));
            await client.DisconnectAsync(timeout.Token);
            AppendLog("Solicitação de desativação aceita pelo servidor.");
        }
        catch (Exception error)
        {
            AppendLog("Reset no servidor não confirmado: " + error.Message);
            if (wasHealthy) AppendLog("O recurso deve encerrar os efeitos quando a sessão expirar.");
        }
        finally
        {
            if (!_closing) ClearSession();
            else client.Dispose();
        }
    }

    private void ClearSession()
    {
        _poll.Stop();
        _debounce.Stop();
        _session?.Cancel();
        _session?.Dispose();
        _session = null;
        _client?.Dispose();
        _client = null;
        _lastStatus = null;
        _healthy = false;
        _connecting = false;
        _sending = false;
        _polling = false;
        _disconnecting = false;
        _reviving = false;
        ResetActiveEffects();
        _eventsCursor = 0;
        _connectionLabel.Text = "DESCONECTADO";
        _connectionLabel.ForeColor = Theme.Muted;
        _connectionDetails.Text = "Nenhuma conexão estabelecida.";
        _revisionLabel.Text = "Conecte ao recurso do seu servidor. Efeitos anteriores podem persistir até 15 s.";
        _serverLabel.Text = "";
        UpdateAvailability();
    }

    private void ResetActiveEffects()
    {
        if (!_dirty || _settings.Aim.Enabled || _settings.Aim.DrawFov || _settings.Silent.Enabled || _settings.Silent.DrawFov ||
            _settings.Weapons.NoRecoil || _settings.Weapons.NoSpread || _settings.Weapons.FreezeAmmo ||
            _settings.Player.GodMode || _settings.Player.Noclip || _settings.Esp.Enabled)
            _changeVersion++;
        _settings.Aim.Enabled = false;
        _settings.Aim.DrawFov = false;
        _settings.Silent.Enabled = false;
        _settings.Silent.DrawFov = false;
        _settings.Weapons.NoRecoil = false;
        _settings.Weapons.NoSpread = false;
        _settings.Weapons.FreezeAmmo = false;
        _settings.Player.GodMode = false;
        _settings.Player.Noclip = false;
        _settings.Esp.Enabled = false;
        SynchronizeToggles();
        _dirty = true;
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        _hotkeyRegistered = NativeHotKeys.RegisterHotKey(Handle, NativeHotKeys.ToggleMenuId, NativeHotKeys.NoRepeat, NativeHotKeys.InsertKey);
        if (_hotkeyRegistered)
            _hotkeyLabel.Text = "Insert · ocultar / mostrar";
        else
        {
            _hotkeyLabel.Text = "Insert indisponível nesta sessão";
            _tooltips.SetToolTip(_hotkeyLabel, "Outro programa pode estar usando Insert. O menu continua acessível pela barra de tarefas.");
        }
    }

    protected override void OnHandleDestroyed(EventArgs e)
    {
        if (_hotkeyRegistered)
        {
            NativeHotKeys.UnregisterHotKey(Handle, NativeHotKeys.ToggleMenuId);
            _hotkeyRegistered = false;
        }
        base.OnHandleDestroyed(e);
    }

    protected override void WndProc(ref Message message)
    {
        if (message.Msg == NativeHotKeys.HotKeyMessage && message.WParam.ToInt32() == NativeHotKeys.ToggleMenuId)
        {
            if (!_closing)
            {
                if (Visible) Hide();
                else
                {
                    Show();
                    if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                    Activate();
                }
            }
            return;
        }
        base.WndProc(ref message);
    }

    private void AppendLog(string message)
    {
        if (_closing || IsDisposed) return;
        if (_eventLog.TextLength > 50000) _eventLog.Text = _eventLog.Text[^30000..];
        _eventLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
    }

    private static string PreferencesPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ZyonMenu", "endpoint.txt");

    private static string LoadEndpoint()
    {
        try
        {
            if (File.Exists(PreferencesPath)) return File.ReadAllText(PreferencesPath).Trim();
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
        return "http://127.0.0.1:30120/zyon_admin_menu/";
    }

    private void SaveEndpoint(string endpoint)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PreferencesPath)!);
            File.WriteAllText(PreferencesPath, endpoint);
        }
        catch (IOException error) { AppendLog("Preferência de URL não foi salva: " + error.Message); }
        catch (UnauthorizedAccessException error) { AppendLog("Preferência de URL não foi salva: " + error.Message); }
    }

    private async void OnFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_closing) return;
        e.Cancel = true;
        _closing = true;
        Enabled = false;
        await DisconnectAsync();
        _session?.Cancel();
        _session?.Dispose();
        _debounce.Dispose();
        _poll.Dispose();
        _tooltips.Dispose();
        _token.Clear();
        Close();
    }
}
