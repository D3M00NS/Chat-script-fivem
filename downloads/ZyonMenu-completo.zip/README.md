# Zyon v2 — menu externo FiveM

Aplicativo Windows 10 x64 com interface escura e controles inspirados na imagem enviada. A versão 2 detecta a cidade automaticamente, sem pedir chave de acesso nem URL na janela. O executável se conecta ao recurso `zyon_admin_menu` instalado no seu FXServer por uma sessão administrativa autorizada.

**Abrir somente o executável não ativa as funções no FiveM.** Instale e inicie o recurso no servidor e entre na cidade com uma conta que tenha a permissão administrativa indicada abaixo. Use o aplicativo e o recurso da mesma versão.

O pacote completo inclui o executável com runtime .NET embutido, o recurso FiveM e o código-fonte. O pacote compacto precisa do .NET Desktop Runtime 8 x64 instalado. Os arquivos publicados ficam na [branch de downloads](https://github.com/D3M00NS/Chat-script-fivem/tree/download-zyon-menu-v1/downloads).

## Instalar

1. Copie `fivem/zyon_admin_menu` para `resources/[local]/zyon_admin_menu` no servidor, mantendo o nome da pasta.
2. Acrescente estas linhas ao `server.cfg`, aproveitando o grupo administrativo já existente no servidor:

   ```cfg
   add_ace group.admin zyon.modmenu allow
   ensure zyon_admin_menu
   ```

   O jogador precisa pertencer a `group.admin` na configuração de administradores do seu servidor. Não é necessário copiar uma licença nem gerar uma chave de acesso para este recurso.
3. Reinicie o recurso, ou reinicie o servidor. Entre na cidade com esse jogador administrador.
4. Abra `ZyonMenu.exe` no mesmo computador em que está jogando FiveM. Aguarde a detecção; a aba Conexão mostra o jogador e o endereço encontrados automaticamente. Todas as funções começam desligadas.

Se FXServer e jogo estiverem no mesmo computador, o recurso usa o endereço loopback e a porta reais informados pelo FiveM. Quando o servidor estiver em outro computador, configure também no `server.cfg`, antes de iniciar o recurso:

```cfg
set zyon_menu_public_url "https://admin.example.com/zyon_admin_menu/"
```

Substitua o exemplo pela URL HTTPS completa do recurso, acessível do computador do jogador e com certificado válido. Um proxy HTTPS pode encaminhar esse caminho ao recurso FXServer. HTTP em endereço remoto, incluindo IP de rede local, é recusado. O aplicativo recebe essa URL automaticamente; você não a digita na janela. Veja [a configuração do recurso](fivem/zyon_admin_menu/README.md) e [o exemplo de configuração](fivem/zyon_admin_menu/config.example.cfg).

O pareamento usa uma credencial interna temporária, criada pelo navegador do FiveM e mantida apenas em memória. Ela permanece invisível e não exige configuração manual. O recurso autoriza a sessão pelo jogador conectado e pela permissão ACE; somente uma sessão de controle fica ativa por vez.

A tecla **Insert** mostra ou oculta a janela; ocultar mantém a sessão conectada. Para encerrar os modificadores, use **Desconectar**. Isso interrompe a detecção automática e envia a desativação ao servidor; confirme o resultado no jogo. Use **Detectar FiveM** para voltar a conectar. Se a desativação não chegar ao servidor, os efeitos podem persistir até a expiração da sessão, após 15 segundos sem heartbeat.

Se a janela ficar em **Aguardando FiveM**, confira se o recurso foi copiado com o nome `zyon_admin_menu`, está iniciado e foi atualizado junto com o aplicativo. O diagnóstico de falta de permissão pede a ACE `zyon.modmenu`; o diagnóstico de HTTPS pede a configuração da URL pública no servidor. Se a detecção local não iniciar, verifique se outra instância do aplicativo está aberta e usando a porta local `39743`.

## Funções

| Controle | Implementação |
| --- | --- |
| Aimbot Aim | Direcionamento da câmera enquanto a tecla escolhida está pressionada; cabeça/pescoço/peito, visibilidade, jogadores/NPCs, suavização e FOV em pixels. |
| ESP | Caixas, esqueleto, nome/ID e distância de entidades presentes no streaming do cliente; até 64 entidades desenhadas. |
| GodMode | Imunidade ao dano nativo do personagem. Scripts que alterem diretamente a vida ou estados médicos podem continuar agindo. |
| Reviver | Ressurreição nativa do GTA; não altera o estado médico de ESX, QBCore ou outros frameworks. |
| Noclip | A pé: WASD, Space/Ctrl para subir/descer, Shift para acelerar. |
| No Recoil | Supressão do tremor nativo de recuo; scripts próprios de câmera podem ter outro comportamento. |
| No Spread | Ajuste nativo de dispersão da arma. |
| Freeze Ammo | Reposição do consumo observado de munição; não concede arma nem cria munição em uma arma vazia. |
| Silent Aim | Desativado: redirecionamento de projéteis não implementado. O servidor também recusa sua ativação. |

As opções começam desligadas. Perda de conexão, jogador desconectado ou sessão encerrada limpa os interruptores locais; a recuperação inicia uma sessão com efeitos desligados. Valores nativos de dano, colisão, congelamento, recuo e dispersão possuem restauração ao desativar. Outro recurso pode modificar as mesmas propriedades; verifique a interação no seu servidor.

## Verificação feita

- Publicação Windows x64 com runtime embutido; compilação sem erros ou avisos.
- Testes .NET da autenticação, transporte HTTP real em loopback, pareamento local, validação das configurações, respostas inválidas, redirecionamentos e cancelamento.
- Contratos do servidor com mocks: identificação real do jogador, ACE, pareamento e renovação automática, mensagens, revisões, expiração e comandos atrasados após desconexão.
- Mocks do cliente: seleção de alvo, desenho, eventos, replay, expiração e restauração dos estados nativos.
- Contratos do pareamento Lua e NUI com mocks: nonce criptográfico, respostas correlacionadas, descoberta do aplicativo, cancelamento por timeout, desconexão, validação de HTTPS e ausência de persistência de credenciais.
- As assinaturas usadas foram consultadas nas referências oficiais do CitizenFX.

A construção foi feita em Linux. **A janela não foi executada no Windows e as funções não foram validadas em uma sessão real de FiveM.** Confirmação de revisão significa que o script do cliente reportou a execução, não que um teste de gameplay foi realizado. A compatibilidade com seu framework médico e seus recursos de armas permanece pendente.

## Compilar a partir do código

Instale o SDK .NET 8.0.426 ou uma atualização compatível da mesma faixa. Em PowerShell:

```powershell
.\scripts\build.ps1
```

O executável sai em `dist/win-x64/ZyonMenu.exe`. Para os testes, instale também Lua 5.4 e Node.js 18 ou posterior:

```powershell
.\scripts\test.ps1 -LuaPath "C:\ferramentas\lua.exe"
```

O parâmetro `-NodePath` aceita o caminho do Node quando ele não estiver no `PATH`. Em Linux com .NET, Lua 5.4 e Node.js instalados, use `bash scripts/test.sh`. Não há dependências NuGet de terceiros no aplicativo nem pacotes externos nos testes NUI; os pacotes de referência e runtime .NET são da Microsoft.

## Arquivos

- `src/ZyonMenu.Windows`: janela e controles WinForms.
- `src/ZyonMenu.Core`: modelos e cliente HTTP autenticado.
- `fivem/zyon_admin_menu`: recurso do servidor e do cliente FiveM.
- `tests`: verificações automatizadas.
- `SHA256SUMS.txt`: hashes dos arquivos entregues.

Os executáveis enviados para análise não são incluídos neste projeto. O runtime .NET redistribuído mantém os avisos de licença em `licenses/`.
