# Zyon — menu externo FiveM

Aplicativo Windows 10 x64 com interface escura e controles inspirados na imagem enviada. O executável se conecta ao recurso `zyon_admin_menu` instalado no seu FXServer. Esse recurso é necessário para aplicar as funções: o programa externo controla as APIs do jogo por uma sessão administrativa autenticada.

O pacote inclui um executável com o runtime .NET embutido, o recurso FiveM e o código-fonte. Não é necessário instalar o .NET para executar o `.exe`.

## Instalar

1. Copie `fivem/zyon_admin_menu` para `resources/[local]/zyon_admin_menu` no servidor, mantendo o nome da pasta.
2. Siga [a configuração do recurso](fivem/zyon_admin_menu/README.md): gere seu token localmente, configure sua licença `license:...` e a permissão ACE `zyon.modmenu`. Use `config.example.cfg` como referência; o token `CHANGE_ME` é recusado.
3. Inicie o recurso e entre na cidade com o jogador configurado.
4. Execute `ZyonMenu.exe`, abra a aba Conexão e informe o token e a URL do recurso. Se FXServer e aplicativo estiverem no mesmo computador: `http://127.0.0.1:30120/zyon_admin_menu/`. Para conectar a outro computador, use HTTPS com certificado válido.

O aplicativo não grava o token. Somente o endereço do recurso é salvo nas preferências locais. A tecla **Insert** mostra ou oculta a janela; ocultar mantém a sessão conectada. Para encerrar os modificadores, use **Desconectar**. A solicitação de desativação é enviada ao servidor; confirme o resultado no jogo. Também existe expiração de sessão após 15 segundos sem heartbeat.

## Funções

| Controle | Implementação |
| --- | --- |
| Aimbot Aim | Direcionamento da câmera enquanto a tecla escolhida está pressionada; cabeça/pescoço/peito, visibilidade, jogadores/NPCs, suavização e FOV em pixels. |
| ESP | Caixas, esqueleto, nome/ID e distância de entidades presentes no streaming do cliente; até 64 entidades desenhadas. |
| GodMode | Imunidade ao dano nativo do personagem. Scripts que alterem diretamente a vida ou estados médicos podem continuar agindo. |
| Reviver | Ressurreição nativa do GTA; não altera o estado médico de ESX, QBCore ou outros frameworks. |
| Noclip | A pé: WASD, Space/Ctrl para subir/descer, Shift para acelerar. |
| No Recoil | Supressão do tremor nativo de recuo; scripts próprios de câmera podem ter outro comportamento. |
| No Spread | Ajuste nativo de dispersão da arma. |
| Freeze Ammo | Reposição do consumo observado de munição; não concede arma nem cria munição em uma arma vazia. |
| Silent Aim | Desativado: redirecionamento de projéteis não implementado. O servidor também recusa sua ativação. |

As opções começam desligadas. Perda de conexão, jogador desconectado ou sessão encerrada limpa os interruptores locais; a recuperação inicia uma sessão com efeitos desligados. Valores nativos de dano, colisão, congelamento, recuo e dispersão possuem restauração ao desativar. Outro recurso pode modificar as mesmas propriedades; verifique a interação no seu servidor.

## Verificação feita

- Publicação Windows x64 com runtime embutido; compilação sem erros ou avisos.
- Testes .NET da autenticação, transporte HTTP real em loopback, validação das configurações, respostas inválidas, redirecionamentos e cancelamento.
- Contratos do servidor com mocks: licença/ACE, mensagens, revisões, expiração e comandos atrasados após desconexão.
- Mocks do cliente: seleção de alvo, desenho, eventos, replay, expiração e restauração dos estados nativos.
- As assinaturas usadas foram consultadas nas referências oficiais do CitizenFX.

A construção foi feita em Linux. **A janela não foi executada no Windows e as funções não foram validadas em uma sessão real de FiveM.** Confirmação de revisão significa que o script do cliente reportou a execução, não que um teste de gameplay foi realizado. A compatibilidade com seu framework médico e seus recursos de armas permanece pendente.

## Compilar a partir do código

Instale o SDK .NET 8.0.426 ou uma atualização compatível da mesma faixa. Em PowerShell:

```powershell
.\scripts\build.ps1
```

O executável sai em `dist/win-x64/ZyonMenu.exe`. Para testes .NET e Lua 5.4:

```powershell
.\scripts\test.ps1 -LuaPath "C:\ferramentas\lua.exe"
```

Em Linux com .NET e Lua 5.4 instalados, use `bash scripts/test.sh`. Não há dependências NuGet de terceiros no aplicativo; os pacotes de referência e runtime são da Microsoft.

## Arquivos

- `src/ZyonMenu.Windows`: janela e controles WinForms.
- `src/ZyonMenu.Core`: modelos e cliente HTTP autenticado.
- `fivem/zyon_admin_menu`: recurso do servidor e do cliente FiveM.
- `tests`: verificações automatizadas.
- `SHA256SUMS.txt`: hashes dos arquivos entregues.

Os executáveis enviados para análise não são incluídos neste projeto. O runtime .NET redistribuído mantém os avisos de licença em `licenses/`.
