#!/usr/bin/env bash
# Bash / scripts/test.sh / Linux, .NET 8 SDK and Lua 5.4 / automated contract tests
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
if [[ -x tools/dotnet/dotnet ]]; then
    menu_dotnet="$project_root/tools/dotnet/dotnet"
else
    menu_dotnet=dotnet
fi
if [[ -x tools/lua54 ]]; then
    menu_lua="$project_root/tools/lua54"
elif command -v lua5.4 >/dev/null 2>&1; then
    menu_lua=lua5.4
else
    menu_lua=lua
fi
mkdir -p .build/runtime .build/dotnet-home .build/nuget .build/xdg-data .build/tmp
chmod 700 .build/runtime
export DOTNET_CLI_HOME="${DOTNET_CLI_HOME:-$project_root/.build/dotnet-home}"
export NUGET_PACKAGES="${NUGET_PACKAGES:-$project_root/.build/nuget}"
export XDG_DATA_HOME="${XDG_DATA_HOME:-$project_root/.build/xdg-data}"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-$project_root/.build/runtime}"
export TMPDIR="${TMPDIR:-$project_root/.build/tmp}"
export DOTNET_NOLOGO=1 DOTNET_CLI_TELEMETRY_OPTOUT=1
"$menu_dotnet" run --project tests/ZyonMenu.Core.Tests/ZyonMenu.Core.Tests.csproj -c Release
"$menu_lua" tests/server_contract.lua
"$menu_lua" tests/client_targeting.lua
