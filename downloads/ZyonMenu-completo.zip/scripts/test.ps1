# PowerShell / scripts/test.ps1 / PowerShell 5.1+, .NET 8, Lua 5.4 and Node.js 18+ / automated contract tests
param([string]$LuaPath = 'lua', [string]$NodePath = 'node')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    & dotnet run --project tests/ZyonMenu.Core.Tests/ZyonMenu.Core.Tests.csproj -c Release
    if ($LASTEXITCODE -ne 0) { throw "Os testes .NET falharam com código $LASTEXITCODE." }
    & $LuaPath tests/server_contract.lua
    if ($LASTEXITCODE -ne 0) { throw "O contrato do servidor falhou com código $LASTEXITCODE." }
    & $LuaPath tests/client_targeting.lua
    if ($LASTEXITCODE -ne 0) { throw "Os testes do cliente falharam com código $LASTEXITCODE." }
    & $LuaPath tests/pairing_client.lua
    if ($LASTEXITCODE -ne 0) { throw "O contrato de pareamento do cliente falhou com código $LASTEXITCODE." }
    & $NodePath --test tests/nui_pairing.test.mjs
    if ($LASTEXITCODE -ne 0) { throw "Os testes de pareamento NUI falharam com código $LASTEXITCODE." }
} finally {
    Pop-Location
}
