# PowerShell / scripts/test.ps1 / PowerShell 5.1+, .NET 8, Lua 5.4 / automated contract tests
param([string]$LuaPath = 'lua')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    & dotnet run --project tests/ZyonMenu.Core.Tests/ZyonMenu.Core.Tests.csproj -c Release
    if ($LASTEXITCODE -ne 0) { throw "Os testes .NET falharam com código $LASTEXITCODE." }
    & $LuaPath tests/server_contract.lua
    if ($LASTEXITCODE -ne 0) { throw "O contrato do servidor falhou com código $LASTEXITCODE." }
    & $LuaPath tests/client_targeting.lua
    if ($LASTEXITCODE -ne 0) { throw "Os testes do cliente falharam com código $LASTEXITCODE." }
} finally {
    Pop-Location
}
