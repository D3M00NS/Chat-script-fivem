# Python / scripts/package.py / Python 3.10+ / reviewed Windows 10 x64 distribution archives
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    for name in ('core-passed', 'server-passed', 'client-assertions', 'pairing-lua-assertions', 'nui-passed'):
        parser.add_argument('--' + name, type=int, required=True)
    args = parser.parse_args()
    counts = vars(args)
    if any(value <= 0 for value in counts.values()):
        parser.error('Use the counts from completed passing test runs.')
    root = Path(__file__).resolve().parent.parent
    results = []
    for label, directory, contained in [('completo', 'win-x64', True), ('compacto', 'win-x64-compact', False)]:
        exe = root / 'dist' / directory / 'ZyonMenu.exe'
        if not exe.is_file():
            raise FileNotFoundError(exe)
        stage = root / 'dist' / ('package-v2-' + label)
        if stage.exists():
            shutil.rmtree(stage)
        stage.mkdir(parents=True)
        for folder in ('src', 'fivem', 'scripts', 'tests', 'docs'):
            shutil.copytree(root / folder, stage / folder,
                            ignore=shutil.ignore_patterns('bin', 'obj', '__pycache__', '*.pyc'))
        for filename in ('README.md', 'global.json', 'Directory.Build.props', '.gitignore'):
            shutil.copy2(root / filename, stage / filename)
        shutil.copy2(exe, stage / 'ZyonMenu.exe')
        licenses = stage / 'licenses'
        licenses.mkdir()
        for source, target in [('LICENSE.txt', 'dotnet-LICENSE.txt'), ('ThirdPartyNotices.txt', 'dotnet-ThirdPartyNotices.txt')]:
            shutil.copy2(root / 'tools' / 'dotnet' / source, licenses / target)
        build = {
            'version': '2.0.0', 'sdk': '8.0.426', 'runtime': '8.0.32', 'target': 'Windows 10 x64',
            'selfContained': contained, 'buildHost': 'Linux', 'automaticPairing': True,
            'manualAccessKeyRequired': False, 'requiredResource': 'zyon_admin_menu',
            'tests': {
                'coreCasesPassed': args.core_passed, 'serverContractCasesPassed': args.server_passed,
                'clientMockAssertionsPassed': args.client_assertions,
                'pairingClientMockAssertionsPassed': args.pairing_lua_assertions,
                'nuiMockCasesPassed': args.nui_passed,
            },
            'windowsGuiExecuted': False, 'fiveMGameplayValidated': False,
            'silentAimImplemented': False, 'exeSha256': sha256(exe),
        }
        (stage / 'BUILDINFO.json').write_text(json.dumps(build, indent=2) + '\n', encoding='utf-8')
        files = sorted(path for path in stage.rglob('*') if path.is_file())
        (stage / 'SHA256SUMS.txt').write_text(''.join(
            sha256(path) + '  ' + path.relative_to(stage).as_posix() + '\n' for path in files), encoding='utf-8')
        archive = root / 'dist' / ('ZyonMenu-' + label + '.zip')
        with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
            for path in sorted(stage.rglob('*')):
                if path.is_file():
                    output.write(path, path.relative_to(stage).as_posix())
        with zipfile.ZipFile(archive) as output:
            corrupt = output.testzip()
            if corrupt:
                raise RuntimeError('Corrupt archive entry: ' + corrupt)
        results.append({'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha256(archive)})
    (root / 'dist' / 'packages-v2.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
