# Referências das APIs usadas

As funções abaixo foram consultadas nas fontes oficiais do CitizenFX durante a implementação. Encontrar a assinatura na documentação não comprova o comportamento em uma sessão real do jogo.

Extensões do FiveM em <https://github.com/citizenfx/fivem/tree/master/ext/native-decls>:

- `SetHttpHandler`: transporte HTTP do FXServer.
- `GetWeaponRecoilShakeAmplitude` e `SetWeaponRecoilShakeAmplitude`: leitura/restauração do tremor de recuo.
- `GetWeaponAccuracySpread` e `SetWeaponAccuracySpread`: leitura/restauração da dispersão.
- `IsEntityPositionFrozen`, `GetGamePool`, `GetActivePlayers` e `GetWorldCoordFromScreenCoord`: estado e seleção/renderização.

Natives GTA em <https://github.com/citizenfx/natives>:

- `GetEntityCanBeDamaged` / `SetEntityCanBeDamaged`, `GetEntityCollisionDisabled` / `SetEntityCollision`, `FreezeEntityPosition`, `SetEntityCoordsNoOffset`.
- `GetAmmoInClip`, `SetAmmoInClip`, `GetAmmoInPedWeapon`, `SetPedAmmo`.
- `SetGameplayCamRelativeHeading`, `SetGameplayCamRelativePitch`, `NetworkResurrectLocalPlayer`.
- `GetScreenCoordFromWorldCoord`, `GetActualScreenResolution`, `DrawLine`, `GetPedBoneIndex`.

Origem de eventos no cliente (`source == 65535`): <https://github.com/citizenfx/fivem-docs/blob/master/content/docs/developers/server-security.md>.

JSON do FXServer: <https://github.com/citizenfx/fivem/blob/master/data/shared/citizen/scripting/lua/json.lua>. O contrato lida com falhas retornadas pelo decoder e não somente com exceções Lua.
