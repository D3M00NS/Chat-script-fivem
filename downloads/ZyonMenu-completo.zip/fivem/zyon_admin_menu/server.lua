-- Lua 5.4 / server.lua / FiveM FXServer / explicitly authorized administrative resource.
local RESOURCE = GetCurrentResourceName()
local VERSION = '1.0.0'
local ACE = 'zyon.modmenu'
local MAX_BODY = 32768
local LEASE_MS = 15000
local MAX_EVENTS = 100
local CAPABILITIES = {
    'aim', 'weapons.noRecoil', 'weapons.noSpread', 'weapons.freezeAmmo',
    'player.godMode', 'player.revive', 'player.noclip', 'esp'
}

local function defaults()
    return {
        aim = { enabled = false, onlyVisible = true, onlyPlayers = true, targetBone = 'Head',
            activationKey = 'RMB', smooth = 1, drawFov = false, fov = 100 },
        silent = { enabled = false, onlyVisible = true, onlyPlayers = true, targetBone = 'Head',
            activationKey = 'RMB', smooth = 1, drawFov = false, fov = 100 },
        weapons = { noRecoil = false, noSpread = false, freezeAmmo = false },
        player = { godMode = false, noclip = false },
        esp = { enabled = false, boxes = true, skeletons = false, names = true, distance = true,
            onlyPlayers = true, onlyVisible = true, maxDistance = 250 }
    }
end

local state = {
    player = nil, active = false, desired = defaults(), desiredRevision = 0,
    appliedRevision = 0, heartbeat = nil, lastDispatch = nil, reviveTicket = 0,
    pendingRevive = nil, cursor = 0, events = {}, buckets = {}, mutationGeneration = 0,
    message = 'Conecte o menu para iniciar uma sessão autorizada.'
}

local function now()
    return GetGameTimer() % 4294967296
end

local function elapsed(current, previous)
    return (current - previous) % 4294967296
end

local function addEvent(kind, message)
    state.cursor = state.cursor + 1
    state.events[#state.events + 1] = { id = state.cursor, type = kind, message = message }
    if #state.events > MAX_EVENTS then table.remove(state.events, 1) end
    state.message = message
end

local function configuration()
    local token = GetConvar('zyon_menu_token', '')
    local license = GetConvar('zyon_menu_license', ''):lower()
    if #token < 32 or #token > 512 or token:find('%s') or token:find('%c') then
        return nil, nil, 'Configure zyon_menu_token com um segredo aleatório de pelo menos 32 caracteres.'
    end
    if not license:match('^license:%x+$') or #license ~= 48 then
        return token, nil, 'Configure zyon_menu_license com o identificador license: do administrador.'
    end
    return token, license
end

local function boundPlayer()
    local _, license, reason = configuration()
    if not license then return nil, reason end
    for _, candidate in ipairs(GetPlayers()) do
        local id = tonumber(candidate)
        if id then
            for _, identifier in ipairs(GetPlayerIdentifiers(id)) do
                if type(identifier) == 'string' and identifier:lower() == license then
                    if IsPlayerAceAllowed(id, ACE) then return id end
                    return nil, 'O jogador configurado não possui a permissão ACE zyon.modmenu.'
                end
            end
        end
    end
    return nil, 'O jogador configurado está desconectado.'
end

local function clearSession(message, notify)
    local prior = state.player
    state.mutationGeneration = state.mutationGeneration + 1
    state.desiredRevision = state.desiredRevision + 1
    state.desired = defaults()
    state.appliedRevision = 0
    state.player = nil
    state.active = false
    state.heartbeat = nil
    state.lastDispatch = nil
    state.pendingRevive = nil
    if notify ~= false and prior then
        TriggerClientEvent('zyon_admin_menu:apply', prior, state.desired, state.desiredRevision)
    end
    addEvent('session', message)
end

local function validateSession()
    if not state.active then return end
    local selected, reason = boundPlayer()
    if selected ~= state.player then
        clearSession(reason or 'O jogador autorizado foi alterado.', true)
    elseif not state.heartbeat or elapsed(now(), state.heartbeat) >= LEASE_MS then
        clearSession('Sessão expirada; desativação solicitada ao cliente.', true)
    end
end

local function constantEqual(left, right)
    local difference = #left ~ #right
    for i = 1, math.max(#left, #right) do
        difference = difference | ((left:byte(i) or 0) ~ (right:byte(i) or 0))
    end
    return difference == 0
end

local function header(request, wanted)
    for name, value in pairs(request.headers or {}) do
        if type(name) == 'string' and name:lower() == wanted then
            if type(value) == 'string' then return value end
            return nil
        end
    end
    return nil
end

local function authenticated(request)
    local token = configuration()
    if not token then return false end
    local authorization = header(request, 'authorization')
    if not authorization or #authorization > 519 then return false end
    local supplied = authorization:match('^Bearer ([^%s]+)$')
    return supplied and constantEqual(supplied, token) or false
end

local rateLimits = {
    ['/api/status'] = { burst = 8, perSecond = 4 },
    ['/api/events'] = { burst = 4, perSecond = 2 },
    ['/api/settings'] = { burst = 8, perSecond = 4 },
    ['/api/revive'] = { burst = 1, perSecond = 0.5 },
    ['/api/disconnect'] = { burst = 2, perSecond = 1 }
}

local function allowRequest(path)
    local limit = rateLimits[path]
    if not limit then return true end
    local timestamp = now()
    local bucket = state.buckets[path]
    if not bucket then bucket = { tokens = limit.burst, updated = timestamp }; state.buckets[path] = bucket end
    bucket.tokens = math.min(limit.burst, bucket.tokens + elapsed(timestamp, bucket.updated) * limit.perSecond / 1000)
    bucket.updated = timestamp
    if bucket.tokens < 1 then return false end
    bucket.tokens = bucket.tokens - 1
    return true
end

local function respond(response, status, payload, extra)
    local headers = {
        ['Content-Type'] = 'application/json; charset=utf-8',
        ['Cache-Control'] = 'no-store', ['X-Content-Type-Options'] = 'nosniff'
    }
    for key, value in pairs(extra or {}) do headers[key] = value end
    response.writeHead(status, headers)
    response.send(json.encode(payload))
end

local function fail(response, status, message, extra)
    respond(response, status, { message = message }, extra)
end

local function schemaObject(value, keys, name)
    if type(value) ~= 'table' then return nil, name .. ' deve ser um objeto.' end
    local meta = getmetatable(value)
    if type(meta) == 'table' and meta.__jsontype == 'array' then return nil, name .. ' deve ser um objeto.' end
    local expected = {}
    for _, key in ipairs(keys) do expected[key] = true end
    for key in pairs(value) do
        if not expected[key] then return nil, name .. ' contém campo desconhecido.' end
    end
    for _, key in ipairs(keys) do
        if value[key] == nil then return nil, name .. '.' .. key .. ' é obrigatório.' end
    end
    return true
end

local function booleanFields(value, keys, name)
    for _, key in ipairs(keys) do
        if type(value[key]) ~= 'boolean' then return nil, name .. '.' .. key .. ' deve ser booleano.' end
    end
    return true
end

local function integer(value, low, high)
    return type(value) == 'number' and value == math.floor(value) and value >= low and value <= high
end

local function validateSettings(settings)
    local valid, message = schemaObject(settings, { 'aim', 'silent', 'weapons', 'player', 'esp' }, 'settings')
    if not valid then return nil, message end
    for _, name in ipairs({ 'aim', 'silent' }) do
        local item = settings[name]
        valid, message = schemaObject(item, { 'enabled', 'onlyVisible', 'onlyPlayers', 'targetBone',
            'activationKey', 'smooth', 'drawFov', 'fov' }, name)
        if not valid then return nil, message end
        valid, message = booleanFields(item, { 'enabled', 'onlyVisible', 'onlyPlayers', 'drawFov' }, name)
        if not valid then return nil, message end
        if item.targetBone ~= 'Head' and item.targetBone ~= 'Neck' and item.targetBone ~= 'Chest' then
            return nil, name .. '.targetBone deve ser Head, Neck ou Chest.'
        end
        if item.activationKey ~= 'RMB' and item.activationKey ~= 'LMB' and item.activationKey ~= 'Alt'
            and item.activationKey ~= 'Shift' and item.activationKey ~= 'Ctrl' then
            return nil, name .. '.activationKey inválida.'
        end
        if not integer(item.smooth, 1, 20) or not integer(item.fov, 10, 500) then
            return nil, name .. '.smooth ou fov fora dos limites.'
        end
    end
    valid, message = schemaObject(settings.weapons, { 'noRecoil', 'noSpread', 'freezeAmmo' }, 'weapons')
    if not valid then return nil, message end
    valid, message = booleanFields(settings.weapons, { 'noRecoil', 'noSpread', 'freezeAmmo' }, 'weapons')
    if not valid then return nil, message end
    valid, message = schemaObject(settings.player, { 'godMode', 'noclip' }, 'player')
    if not valid then return nil, message end
    valid, message = booleanFields(settings.player, { 'godMode', 'noclip' }, 'player')
    if not valid then return nil, message end
    valid, message = schemaObject(settings.esp, { 'enabled', 'boxes', 'skeletons', 'names', 'distance',
        'onlyPlayers', 'onlyVisible', 'maxDistance' }, 'esp')
    if not valid then return nil, message end
    valid, message = booleanFields(settings.esp, { 'enabled', 'boxes', 'skeletons', 'names', 'distance',
        'onlyPlayers', 'onlyVisible' }, 'esp')
    if not valid then return nil, message end
    if not integer(settings.esp.maxDistance, 25, 1000) then return nil, 'esp.maxDistance fora dos limites.' end
    if settings.silent.enabled then return nil, 'Silent Aim não é suportado por este recurso.' end
    return settings
end

local function selectForCommand(response)
    validateSession()
    local target, reason = boundPlayer()
    if not target then fail(response, 409, reason); return nil end
    if state.player and state.player ~= target then clearSession('O jogador autorizado foi alterado.', true) end
    state.player = target
    state.active = true
    state.heartbeat = now()
    return target
end

local function withJson(request, response, callback)
    -- A newer authenticated mutation invalidates earlier bodies still arriving over HTTP.
    state.mutationGeneration = state.mutationGeneration + 1
    local generation = state.mutationGeneration
    local _, acceptedLicense = configuration()
    local acceptedPlayer = boundPlayer()
    local contentLength = header(request, 'content-length')
    if contentLength then
        if not contentLength:match('^%d+$') then fail(response, 400, 'Content-Length inválido.'); return end
        if tonumber(contentLength) > MAX_BODY then fail(response, 413, 'Corpo excede 32 KiB.'); return end
    end
    local contentType = header(request, 'content-type')
    local mediaType = contentType and contentType:lower():match('^%s*([^;]+)')
    if not mediaType or mediaType:gsub('%s+$', '') ~= 'application/json' then
        fail(response, 415, 'Content-Type deve ser application/json.'); return
    end
    local completed = false
    request.setCancelHandler(function() completed = true end)
    SetTimeout(5000, function()
        if not completed then completed = true; fail(response, 408, 'Tempo limite de recebimento do JSON.'); end
    end)
    request.setDataHandler(function(body)
        if completed then return end
        completed = true
        if not authenticated(request) then fail(response, 401, 'Autenticação necessária.'); return end
        validateSession()
        if generation ~= state.mutationGeneration then
            fail(response, 409, 'O comando foi substituído ou a sessão foi encerrada.'); return
        end
        local _, currentLicense = configuration()
        if currentLicense ~= acceptedLicense or boundPlayer() ~= acceptedPlayer then
            fail(response, 409, 'A licença, conexão ou permissão do jogador foi alterada.'); return
        end
        if type(body) ~= 'string' or #body > MAX_BODY then fail(response, 413, 'Corpo excede 32 KiB.'); return end
        local decoded, payload, position, decodeError = pcall(json.decode, body)
        if not decoded or decodeError or type(payload) ~= 'table' or type(position) ~= 'number'
            or body:sub(position):find('%S') then fail(response, 400, 'JSON inválido.'); return end
        callback(payload)
    end)
end

SetHttpHandler(function(request, response)
    if not authenticated(request) then
        fail(response, 401, 'Autenticação necessária.', { ['WWW-Authenticate'] = 'Bearer' }); return
    end
    local rawPath = request.path or ''
    local path, query = rawPath:match('^([^?]*)%??(.*)$')
    local expectedMethod = ({ ['/api/status'] = 'GET', ['/api/events'] = 'GET',
        ['/api/settings'] = 'POST', ['/api/revive'] = 'POST', ['/api/disconnect'] = 'POST' })[path]
    if not expectedMethod then fail(response, 404, 'Endpoint desconhecido.'); return end
    if request.method ~= expectedMethod then
        fail(response, 405, 'Método não permitido.', { ['Allow'] = expectedMethod }); return
    end
    if not allowRequest(path) then fail(response, 429, 'Limite de requisições excedido.', { ['Retry-After'] = '1' }); return end
    validateSession()
    if path == '/api/status' then
        local token, license, configReason = configuration()
        local target, reason = boundPlayer()
        if state.active and target == state.player then state.heartbeat = now() end
        respond(response, 200, { version = VERSION, ready = token ~= nil and license ~= nil,
            sessionActive = state.active, playerOnline = target ~= nil,
            playerId = target or 0, playerName = target and GetPlayerName(target) or '',
            desiredRevision = state.desiredRevision, appliedRevision = state.appliedRevision,
            message = configReason or reason or state.message, capabilities = CAPABILITIES })
    elseif path == '/api/events' then
        local sinceText = query:match('^since=(%d+)$')
        if query ~= '' and not sinceText then fail(response, 400, 'Use somente ?since=<inteiro>.'); return end
        local since = sinceText and tonumber(sinceText) or 0
        if not since or since > 9007199254740991 then fail(response, 400, 'Cursor inválido.'); return end
        local events = {}
        for _, event in ipairs(state.events) do if event.id > since then events[#events + 1] = event end end
        respond(response, 200, { cursor = state.cursor, events = events })
    elseif path == '/api/settings' then
        withJson(request, response, function(payload)
            local valid, message = schemaObject(payload, { 'settings' }, 'request')
            if not valid then fail(response, 422, message); return end
            local settings
            settings, message = validateSettings(payload.settings)
            if not settings then fail(response, 422, message); return end
            local target = selectForCommand(response)
            if not target then return end
            state.desired = settings
            state.desiredRevision = state.desiredRevision + 1
            state.lastDispatch = now()
            TriggerClientEvent('zyon_admin_menu:apply', target, settings, state.desiredRevision)
            addEvent('requested', 'Configuração enviada; aguardando confirmação do cliente FiveM.')
            respond(response, 200, { revision = state.desiredRevision, message = state.message })
        end)
    elseif path == '/api/revive' then
        withJson(request, response, function(payload)
            local valid, message = schemaObject(payload, {}, 'request')
            if not valid then fail(response, 422, message); return end
            local target = selectForCommand(response)
            if not target then return end
            if not state.lastDispatch then
                if state.desiredRevision == 0 then state.desiredRevision = 1 end
                state.lastDispatch = now()
                TriggerClientEvent('zyon_admin_menu:apply', target, state.desired, state.desiredRevision)
            end
            state.reviveTicket = state.reviveTicket + 1
            state.pendingRevive = { ticket = state.reviveTicket, player = target, sent = now() }
            TriggerClientEvent('zyon_admin_menu:revive', target, state.reviveTicket)
            addEvent('requested', 'Reviver nativo solicitado; aguardando confirmação do cliente.')
            respond(response, 200, { ticket = state.reviveTicket, message = state.message })
        end)
    elseif path == '/api/disconnect' then
        withJson(request, response, function(payload)
            local valid, message = schemaObject(payload, {}, 'request')
            if not valid then fail(response, 422, message); return end
            clearSession('Menu desconectado; desativação solicitada ao cliente.', true)
            respond(response, 200, { revision = state.desiredRevision, message = state.message })
        end)
    end
end)

RegisterNetEvent('zyon_admin_menu:ack', function(revision, success, message)
    local player = tonumber(source)
    validateSession()
    if not state.active or player ~= state.player or boundPlayer() ~= player then return end
    if not integer(revision, 1, 9007199254740991) or revision ~= state.desiredRevision then return end
    if success ~= nil and type(success) ~= 'boolean' then return end
    if success == false then
        local detail = type(message) == 'string' and message:gsub('[%c]', ''):sub(1, 120) or ''
        clearSession(detail ~= '' and detail or 'O cliente rejeitou a configuração; desativação solicitada.', true)
        return
    end
    if state.appliedRevision ~= revision then
        state.appliedRevision = revision
        addEvent('applied', 'Configuração confirmada pelo cliente FiveM.')
    end
end)

RegisterNetEvent('zyon_admin_menu:reviveAck', function(ticket, success, message)
    local player = tonumber(source)
    validateSession()
    local pending = state.pendingRevive
    if not state.active or not pending or player ~= state.player or pending.player ~= player
        or boundPlayer() ~= player or ticket ~= pending.ticket or elapsed(now(), pending.sent) >= 10000
        or type(success) ~= 'boolean' then return end
    state.pendingRevive = nil
    if type(message) ~= 'string' then message = '' end
    message = message:gsub('[%c]', ''):sub(1, 120)
    addEvent(success and 'revived' or 'error', message ~= '' and message
        or (success and 'Reviver nativo confirmado.' or 'O cliente não conseguiu reviver o personagem.'))
end)

AddEventHandler('playerDropped', function()
    if tonumber(source) == state.player then clearSession('Jogador desconectado; sessão encerrada.', false) end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == RESOURCE and state.active then clearSession('Recurso encerrado; desativação solicitada ao cliente.', true) end
end)

CreateThread(function()
    while true do
        Wait(250)
        validateSession()
        local timestamp = now()
        if state.active and (not state.lastDispatch or elapsed(timestamp, state.lastDispatch) >= 5000) then
            state.lastDispatch = timestamp
            TriggerClientEvent('zyon_admin_menu:apply', state.player, state.desired, state.desiredRevision)
        end
        if state.pendingRevive and elapsed(timestamp, state.pendingRevive.sent) >= 10000 then
            state.pendingRevive = nil
            addEvent('error', 'O cliente não confirmou o pedido de reviver em 10 segundos.')
        end
    end
end)
