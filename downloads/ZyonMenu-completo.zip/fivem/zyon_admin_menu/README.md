# Recurso FiveM do menu externo

O executável controla este recurso instalado no FXServer. As ações usam os natives do FiveM no personagem configurado. O servidor valida a mesma licença e a permissão ACE em cada comando, sem receber um ID de jogador escolhido pelo programa externo.

Copie esta pasta para `resources/[local]/zyon_admin_menu`, mantendo esse nome. Use um servidor de desenvolvimento com GTA V/FiveM; RedM não é suportado.

## Configuração

1. Gere um segredo aleatório no computador administrador. No PowerShell do Windows 10:

   ```powershell
   $bytes = New-Object byte[] 32
   $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
   try { $rng.GetBytes($bytes); [Convert]::ToBase64String($bytes) } finally { $rng.Dispose() }
   ```

   Em Linux também pode usar `openssl rand -hex 32`.

2. Copie `config.example.cfg` para sua configuração local, substitua `CHANGE_ME` pelo segredo e os dois identificadores pelo `license:` real do administrador. Obtenha esse identificador pelo painel administrativo do seu servidor. Não use Steam ID, IP, `license2:` ou ID temporário do jogador.

3. No `server.cfg`, depois das definições de permissões, inclua `exec zyon-menu.local.cfg` se esse for o nome escolhido para a configuração. O recurso exige um segredo com pelo menos 32 caracteres e uma licença com 40 caracteres hexadecimais.

4. Inicie o recurso e entre no servidor com a conta configurada. O estado do programa indicará se a licença está online e se a permissão `zyon.modmenu` foi concedida. Use no executável o mesmo segredo e a URL `http://127.0.0.1:30120/zyon_admin_menu/` quando ele estiver no mesmo computador do FXServer.

Use `set` para o segredo, nunca `setr` ou `sets`, pois essas opções podem divulgá-lo aos clientes ou à listagem pública. Mantenha a configuração local fora do controle de versão. O executável não precisa receber permissões de administrador do Windows.

Para conectar a outro computador, publique o endpoint exclusivamente por HTTPS com proxy reverso e restrição de acesso administrativo. O executável aceita HTTP apenas para loopback. O token permanece no servidor e no programa administrador; não é enviado ao cliente FiveM. Não configure CORS nem inclua o segredo na URL.

## Recursos e limites

- Aim: câmera direcionada ao alvo selecionado, filtros de visibilidade/jogadores, osso, suavização e tecla. Não redireciona balas.
- Armas: ajuste nativo da amplitude de tremor de recuo e precisão/spread, com restauração dos valores anteriores. Munição congelada repõe consumo observado e preserva ganhos observados; não deixa um modificador infinito ativo depois de desativar.
- Jogador: GodMode, noclip e reviver nativo do GTA. Sistemas de morte/hospital de ESX, QBCore ou recursos próprios podem exigir integração adicional: esse recurso não altera o estado médico do framework.
- ESP: caixas, esqueleto, nomes e distância para entidades presentes no cliente. Não garante visibilidade de jogadores fora do streaming/OneSync.
- Silent Aim fica desativado e o servidor rejeita tentativas de habilitá-lo.

A conexão envia heartbeat pelo estado a cada poucos segundos. Sem heartbeat por 15 segundos, o servidor solicita a restauração dos padrões. O cliente também mantém uma validade local e restaura os modificadores se perder os sinais do recurso. Desconectar o programa, sair do servidor, remover a permissão, alterar a licença ou parar o recurso encerra a sessão. Outro recurso pode escrever nos mesmos natives; valide a compatibilidade no seu servidor.

As mensagens de encerramento confirmam a solicitação de desativação, sem confirmar a execução do reset no cliente: o servidor fecha a sessão antes desse ACK. Verifique a restauração dentro do FiveM. A validade local do cliente oferece uma segunda via de desativação caso o pacote de reset não seja entregue.

## API

Todas as rotas exigem `Authorization: Bearer <segredo>` antes de processar dados. O prefixo HTTP é `/zyon_admin_menu/`; o FXServer entrega ao handler somente o caminho após esse prefixo.

| Método | Rota | Resposta/ação |
| --- | --- | --- |
| GET | `api/status` | Estado, capacidades, revisão solicitada e revisão confirmada; renova sessão ativa. |
| GET | `api/events?since=0` | Eventos posteriores ao cursor; até 100 eventos são retidos. |
| POST | `api/settings` | JSON `{ "settings": ... }`; snapshot completo validado, até 32 KiB. |
| POST | `api/revive` | JSON `{}`; solicita reviver no jogador vinculado e aguarda confirmação separada. |
| POST | `api/disconnect` | JSON `{}`; solicita os padrões desativados e encerra a sessão. |

`200` em settings significa que o comando foi enviado. Somente o ACK válido do cliente avança `appliedRevision`. No estado, `ready` indica configuração válida e `sessionActive` indica uma sessão efetivamente ativa. Um corpo HTTP antigo é descartado se outro comando tiver sido aceito, a sessão for encerrada ou a licença/conexão/permissão tiver mudado; uma resposta tardia não pode reativar efeitos após desconectar.

Erros usam JSON `{ "message": "..." }`; credenciais inválidas retornam `401`, jogador ausente/sem ACE ou comando substituído `409`, schema não suportado `422` e limite de chamadas `429`. Não há endpoint para escolher outro jogador, executar código, enviar comandos do console ou editar permissões.

A API utiliza `SetHttpHandler` documentado pelo CitizenFX: <https://github.com/citizenfx/fivem/blob/master/ext/native-decls/SetHttpHandler.md>.

## Validação no servidor

Confirme que um token incorreto retorna `401`; uma licença sem ACE não recebe alterações; a revisão solicitada só se torna aplicada depois do ACK; desconectar o executável ou retirar a ACE restaura os modificadores. Teste reviver com o framework da sua cidade antes de considerar integração com seu sistema médico. A validação automatizada disponível usa mocks de FXServer; a validação dos natives requer GTA V e um servidor FiveM em execução.
