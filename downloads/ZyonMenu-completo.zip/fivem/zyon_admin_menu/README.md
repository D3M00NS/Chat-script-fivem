# Recurso FiveM do menu externo

O executável controla este recurso instalado no FXServer. O pareamento identifica automaticamente o administrador conectado ao FiveM: não existe chave para digitar ou licença para copiar. As ações usam os natives do FiveM no personagem pareado. O servidor valida a conexão, a mesma licença real e a permissão ACE em cada comando, sem receber um ID de jogador escolhido pelo programa externo.

Copie esta pasta para `resources/[local]/zyon_admin_menu`, mantendo esse nome. Use um servidor de desenvolvimento com GTA V/FiveM; RedM não é suportado.

## Configuração

1. Instale este recurso atualizado e inclua em `server.cfg` as duas linhas ativas de `config.example.cfg`: a permissão `zyon.modmenu` para o grupo administrador já utilizado pelo servidor e `ensure zyon_admin_menu`. Seus administradores precisam pertencer a esse grupo na configuração ACE existente.

2. Quando o executável e o FXServer estiverem no mesmo computador, o recurso identifica o endereço loopback do servidor. Para um FXServer em outro computador, configure uma vez `zyon_menu_public_url` com a URL HTTPS completa do recurso, por exemplo `https://admin.example.com/zyon_admin_menu/`. Use certificado confiável, proxy reverso e restrição de acesso administrativo. HTTP é aceito apenas para loopback; o programa não envia a credencial automática por HTTP a um servidor remoto.

3. Inicie o recurso, entre no servidor com uma conta que tenha a permissão ACE e abra o executável. O painel deve sair de “aguardando FiveM” para o administrador identificado. Não é necessário preencher chave ou URL no programa. O recurso ainda precisa estar instalado no servidor: abrir somente o executável não disponibiliza a integração.

O NUI gera 32 bytes com `crypto.getRandomValues`, envia o identificador pelo evento do próprio jogador e recebe autorização vinculada à conexão atual. O servidor devolve o resultado somente a esse jogador. A credencial interna segue automaticamente para o programa pelo canal local e autentica a API; ela não aparece em logs ou configurações. O executável não exige permissões de administrador do Windows.

O recurso v2 ignora `zyon_menu_token` e `zyon_menu_license` de configurações antigas. Remova essas linhas depois da atualização; não copie valores para o programa. Mantenha a URL sem credenciais, consulta, fragmento ou chave.

Um pareamento admite um controlador por vez. Renovar o mesmo identificador preserva a sessão e as revisões. Outro administrador recebe recusa enquanto houver uma sessão ativa; um controlador inativo pode ser substituído. Um novo identificador invalida o anterior e solicita a desativação dos efeitos da sessão anterior. Sem renovação pelo cliente FiveM por 120 segundos, o pareamento expira mesmo que o executável continue consultando a API.

## Recursos e limites

- Aim: câmera direcionada ao alvo selecionado, filtros de visibilidade/jogadores, osso, suavização e tecla. Não redireciona balas.
- Armas: ajuste nativo da amplitude de tremor de recuo e precisão/spread, com restauração dos valores anteriores. Munição congelada repõe consumo observado e preserva ganhos observados; não deixa um modificador infinito ativo depois de desativar.
- Jogador: GodMode, noclip e reviver nativo do GTA. Sistemas de morte/hospital de ESX, QBCore ou recursos próprios podem exigir integração adicional: esse recurso não altera o estado médico do framework.
- ESP: caixas, esqueleto, nomes e distância para entidades presentes no cliente. Não garante visibilidade de jogadores fora do streaming/OneSync.
- Silent Aim fica desativado e o servidor rejeita tentativas de habilitá-lo.

A conexão envia heartbeat pelo estado a cada poucos segundos. Sem heartbeat por 15 segundos, o servidor solicita a restauração dos padrões. O cliente também mantém uma validade local e restaura os modificadores se perder os sinais do recurso. Desconectar o programa encerra a sessão de efeitos; o pareamento válido pode continuar disponível para reconectar. Sair do servidor, remover a permissão, mudar de identidade ou parar o recurso revoga também o pareamento. Outro recurso pode escrever nos mesmos natives; valide a compatibilidade no seu servidor.

As mensagens de encerramento confirmam a solicitação de desativação, sem confirmar a execução do reset no cliente: o servidor fecha a sessão antes desse ACK. Verifique a restauração dentro do FiveM. A validade local do cliente oferece uma segunda via de desativação caso o pacote de reset não seja entregue.

## API

Todas as rotas exigem `Authorization: Bearer <credencial automática>` antes de processar dados. A credencial não é configurada manualmente: somente o evento de um jogador autorizado pode registrar um pareamento. Cada pedido HTTP revalida jogador online, licença real e ACE. O prefixo HTTP é `/zyon_admin_menu/`; o FXServer entrega ao handler somente o caminho após esse prefixo.

| Método | Rota | Resposta/ação |
| --- | --- | --- |
| GET | `api/status` | Estado, capacidades, revisão solicitada e revisão confirmada; renova sessão ativa. |
| GET | `api/events?since=0` | Eventos posteriores ao cursor; até 100 eventos são retidos. |
| POST | `api/settings` | JSON `{ "settings": ... }`; snapshot completo validado, até 32 KiB. |
| POST | `api/revive` | JSON `{}`; solicita reviver no jogador vinculado e aguarda confirmação separada. |
| POST | `api/disconnect` | JSON `{}`; solicita os padrões desativados e encerra a sessão. |

`200` em settings significa que o comando foi enviado. Somente o ACK válido do cliente avança `appliedRevision`. No estado, `ready` indica pareamento válido com jogador online e autorizado; `sessionActive` indica uma sessão de efeitos efetivamente ativa. Um corpo HTTP antigo é descartado se outro comando tiver sido aceito, a sessão for encerrada ou o pareamento/conexão/permissão tiver mudado; uma resposta tardia não pode reativar efeitos após desconectar.

Erros usam JSON `{ "message": "..." }`; credenciais ou pareamento inválidos/revogados retornam `401`, comando substituído retorna `409`, schema não suportado `422` e limite de chamadas `429`. Registro de pareamento aceita uma chamada por jogador a cada dois segundos e mantém o histórico de limite de forma limitada. Não há endpoint HTTP público para cadastrar pareamento, escolher outro jogador, executar código, enviar comandos do console ou editar permissões.

A API utiliza `SetHttpHandler` documentado pelo CitizenFX: <https://github.com/citizenfx/fivem/blob/master/ext/native-decls/SetHttpHandler.md>.

## Validação no servidor

Confirme o pareamento automático ao abrir o executável, a recusa para contas sem ACE e a invalidação do pareamento ao sair do servidor. Uma credencial incorreta ou antiga deve retornar `401`; renovar o mesmo pareamento deve preservar as revisões; outro administrador não pode assumir uma sessão ativa. A revisão solicitada só se torna aplicada depois do ACK. Verifique dentro do FiveM a restauração ao desconectar o executável ou retirar a ACE. Teste reviver com o framework da sua cidade antes de considerar integração com seu sistema médico. A validação automatizada disponível usa mocks de FXServer; a validação dos natives e do canal NUI/local requer GTA V e um servidor FiveM em execução.
