@echo off
cd /d "%~dp0"
start "" "ZyonMenu.exe"
