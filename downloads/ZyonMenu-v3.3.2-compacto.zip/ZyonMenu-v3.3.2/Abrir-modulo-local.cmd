@echo off
cd /d "%~dp0"
start "" "ZyonMenu.exe" --client-module
